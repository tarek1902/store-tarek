import hashlib
import json
import os
import platform
import re
import subprocess
import tempfile
from contextlib import contextmanager
from urllib.request import urlopen, Request
from urllib.parse import urlparse


def script_receipts():
    try:
        with open('/etc/enigma2/skyblue-store-script-installed.json',encoding='utf-8') as stream:
            raw=stream.read(262145)
        if len(raw)>262144:return {}
        rows=json.loads(raw)
        return {key:row['version'] for key,row in rows.items() if isinstance(row,dict) and row.get('confirmed') and isinstance(row.get('version'),str)}
    except (OSError,ValueError,TypeError,AttributeError):return {}


def installed_packages():
    """Read opkg state without spawning commands on the GUI thread."""
    for path in ('/var/lib/opkg/status','/usr/lib/opkg/status'):
        try:
            with open(path,encoding='utf-8',errors='replace') as stream:
                text=stream.read()
        except OSError:
            continue
        result={}
        for paragraph in text.split('\n\n'):
            fields=dict(line.split(': ',1) for line in paragraph.splitlines() if ': ' in line and not line.startswith(' '))
            if fields.get('Status','').split()[-1:] == ['installed'] and fields.get('Package'):
                result[fields['Package']]=fields.get('Version','')
        result.update(script_receipts())
        return result
    return {}


def installed_version(item, packages):
    ids=[item.get('package_id',item.get('id',''))]
    for url in item.get('source_urls',[]):
        filename=urlparse(url).path.rsplit('/',1)[-1]
        if filename.endswith('.ipk'):
            ids.append(filename.rsplit('_',2)[0])
    for package_id in ids:
        if package_id in packages:
            return packages[package_id]
    return None


def newer_version(candidate, installed):
    result=subprocess.run(['/usr/bin/opkg','compare-versions',candidate,'>>',installed],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10)
    return result.returncode == 0


def device_info():
    info = {}
    try:
        with open('/etc/os-release') as stream:
            for line in stream:
                key, sep, value = line.strip().partition('=')
                if sep:
                    info[key] = value.strip('"')
    except OSError:
        pass
    try:
        with open('/etc/image-version') as stream:
            image = dict(line.strip().split('=', 1) for line in stream if '=' in line)
        if not info.get('ID'):
            info['ID'] = image.get('distro', image.get('creator', 'unknown')).lower()
        if not info.get('VERSION_ID'):
            info['VERSION_ID'] = image.get('version', '')
    except OSError:
        pass
    return {'image': info.get('ID', 'unknown'), 'version': info.get('VERSION_ID', ''),
            'arch': platform.machine(), 'python': platform.python_version()}


def secure_url(url):
    parsed = urlparse(url)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('يلزم رابط HTTPS صالح')
    return url


def read_catalog(path):
    local_root = None
    if path.startswith('https://'):
        with urlopen(Request(secure_url(path), headers={'User-Agent': 'SkyBlueStore/0.1'}), timeout=15) as response:
            secure_url(response.geturl())
            raw = response.read(1024 * 1024 + 1)
        if len(raw) > 1024 * 1024:
            raise ValueError('حجم الكتالوج أكبر من الحد المسموح')
        data = json.loads(raw.decode('utf-8'))
    else:
        local_root = os.path.dirname(os.path.realpath(path))
        with open(path, encoding='utf-8') as stream:
            data = json.load(stream)
    if data.get('schema') != 1 or not isinstance(data.get('items'), list):
        raise ValueError('صيغة الكتالوج غير مدعومة')
    for item in data['items']:
        if not isinstance(item, dict):
            raise ValueError('عنصر كتالوج غير صالح')
        if item.get('reference_only') is True:
            if not all(isinstance(item.get(key), str) for key in ('id', 'name', 'category', 'description')):
                raise ValueError('مرجع كتالوج غير صالح')
            continue
        for field in ('id', 'name', 'version', 'category', 'description', 'url', 'sha256', 'architectures', 'images', 'python_major'):
            if field not in item:
                raise ValueError('حقل مفقود: ' + field)
        if item.get('bundle') and local_root:
            bundled_path(item, local_root)
            item['_bundle_root'] = local_root
        else:
            secure_url(item['url'])
            item.pop('_bundle_root', None)
        if not re.fullmatch(r'[a-fA-F0-9]{64}', item['sha256']):
            raise ValueError('بصمة الحزمة غير صالحة')
        if not all(isinstance(item[key], list) and item[key] for key in ('architectures', 'images', 'python_major')):
            raise ValueError('قائمة توافق الحزمة غير صالحة')
        if not all(isinstance(item[key], str) for key in ('id', 'name', 'version', 'category', 'description')):
            raise ValueError('بيانات الحزمة غير صالحة')
    return data['items']


def compatible(item, info):
    if item.get('reference_only'):
        return False
    return (info['arch'] in item['architectures'] and info['image'] in item['images']
            and int(info['python'].split('.')[0]) in item['python_major'])


def bundled_path(item, root):
    name = item.get('bundle', '')
    if not isinstance(name, str) or not re.fullmatch(r'[a-zA-Z0-9_+.-]+\.ipk', name):
        raise ValueError('اسم حزمة محلية غير صالح')
    parent = os.path.realpath(os.path.join(root, 'packages'))
    path = os.path.realpath(os.path.join(parent, name))
    if os.path.dirname(path) != parent or not os.path.isfile(path):
        raise ValueError('الحزمة المحلية غير موجودة')
    return path


@contextmanager
def package_stream(item):
    if item.get('_bundle_root'):
        with open(bundled_path(item, item['_bundle_root']), 'rb') as stream:
            yield stream
    else:
        with urlopen(secure_url(item['url']), timeout=30) as stream:
            secure_url(stream.geturl())
            yield stream


def install(item, info):
    if not compatible(item, info):
        raise ValueError('هذه الحزمة غير متوافقة مع الجهاز أو الصورة')
    if not os.path.isfile('/usr/bin/opkg'):
        raise ValueError('هذه النسخة تدعم صور opkg فقط')
    if not urlparse(item['url']).path.endswith('.ipk'):
        raise ValueError('الحزمة يجب أن تكون بصيغة IPK')
    fd, path = tempfile.mkstemp(prefix='skyblue-store-', suffix='.ipk')
    try:
        digest = hashlib.sha256()
        total = 0
        with os.fdopen(fd, 'wb') as output:
            with package_stream(item) as response:
                while True:
                    chunk = response.read(65536)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > 100 * 1024 * 1024:
                        raise ValueError('حجم الحزمة يتجاوز 100 MB')
                    digest.update(chunk)
                    output.write(chunk)
        if digest.hexdigest().lower() != item['sha256'].lower():
            raise ValueError('فشل التحقق من سلامة الحزمة')
        from .resolver import check_install_hooks
        with open(path,'rb') as package:
            check_install_hooks(package.read())
        result = subprocess.run(['/usr/bin/opkg', 'install', path], stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=180)
        if result.returncode:
            raise RuntimeError(result.stdout.decode('utf-8', 'replace')[-1500:])
        return 'تم التثبيت. قد تحتاج إعادة تشغيل الواجهة حسب الإضافة.'
    finally:
        if os.path.exists(path):
            os.unlink(path)
