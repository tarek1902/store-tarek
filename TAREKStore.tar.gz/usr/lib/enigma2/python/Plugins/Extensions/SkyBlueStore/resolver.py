"""Read upstream installer text as data; never evaluate or run shell commands."""
import hashlib
import io
import re
import tarfile
from urllib.parse import urlparse
from .core import secure_url, urlopen


def download(url, limit):
    with urlopen(secure_url(url), timeout=25) as response:
        secure_url(response.geturl())
        raw=response.read(limit+1)
    if len(raw)>limit:
        raise ValueError('الملف أكبر من حد الفحص المسموح')
    return raw


def ipk_links(text):
    links=re.findall(r'https://[^\s\x22\x27<>|;]+',text)
    return sorted(set(url for url in links if urlparse(url).path.endswith('.ipk') and not any(c in url for c in '$`{}\\')))


def package_metadata(raw):
    if not raw.startswith(b'!<arch>\n'):
        raise ValueError('الملف المستلم ليس حزمة IPK صالحة')
    offset=8
    while offset+60 <= len(raw):
        header=raw[offset:offset+60]
        if header[58:60]!=b'`\n':
            raise ValueError('بنية IPK غير صالحة')
        size=int(header[48:58])
        if size<0 or offset+60+size>len(raw):
            raise ValueError('حزمة IPK غير مكتملة')
        name=header[:16].decode('ascii').strip().rstrip('/')
        if name.startswith('control.tar.'):
            if size>1024*1024:
                raise ValueError('ملف بيانات الحزمة كبير بشكل غير متوقع')
            with tarfile.open(fileobj=io.BytesIO(raw[offset+60:offset+60+size]),mode='r:*') as archive:
                for member in archive:
                    if member.name.lstrip('./')=='control' and member.isfile() and member.size<=65536:
                        text=archive.extractfile(member).read().decode('utf-8','replace')
                        return dict(line.split(':',1) for line in text.splitlines() if ':' in line and not line.startswith(' '))
            break
        offset+=60+size+size%2
    raise ValueError('لا توجد بيانات تعريف للحزمة')


def check_install_hooks(raw):
    """Reject package hooks that stop the running receiver interface."""
    if not raw.startswith(b'!<arch>\n'):
        raise ValueError('حزمة IPK غير صالحة')
    offset=8
    while offset+60<=len(raw):
        header=raw[offset:offset+60];size=int(header[48:58])
        if size<0 or offset+60+size>len(raw):raise ValueError('حزمة IPK غير مكتملة')
        if header[:16].strip().rstrip(b'/').startswith(b'control.tar.'):
            if size>1024*1024:raise ValueError('ملف بيانات الحزمة كبير')
            with tarfile.open(fileobj=io.BytesIO(raw[offset+60:offset+60+size]),mode='r:*') as archive:
                for member in archive:
                    if member.name.lstrip('./') not in ('preinst','postinst','prerm','postrm'):continue
                    if not member.isfile() or member.size>65536:raise ValueError('ملف أوامر الحزمة غير صالح')
                    text=archive.extractfile(member).read().decode('utf-8','replace')
                    active='\n'.join(line for line in text.splitlines() if not line.lstrip().startswith('#'))
                    if re.search(r'\binit\s+[0346]\b|\bkillall\b[^\n;]*enigma2|\bsystemctl\b[^\n;]*(?:restart|stop|reboot)|\b(?:reboot|poweroff|halt)\b|/etc/init.d/[^\s;]+\s+(?:stop|restart)',active):
                        raise ValueError('توقّف التثبيت: الحزمة توقف واجهة الجهاز تلقائيًا. تحتاج نسخة مثبّت لا تقطع الواجهة.')
            return
        offset+=60+size+size%2
    raise ValueError('لا توجد بيانات أوامر الحزمة')


def resolve_reference(item, info):
    if item.get('target_python_major') and int(info['python'].split('.')[0]) not in item['target_python_major']:
        raise ValueError('هذه النسخة مخصصة لإصدار Python مختلف')
    if item.get('target_images') and info['image'] not in item['target_images']:
        raise ValueError('هذه الحزمة مخصصة لصورة أخرى: '+', '.join(item['target_images']))
    if info['image']!='openatv':
        raise ValueError('الجلب التلقائي متاح حاليًا لصورة OpenATV فقط')
    candidates=set()
    for source in item.get('source_urls',[])[:4]:
        secure_url(source)
        if urlparse(source).path.endswith('.ipk'):
            candidates.add(source)
        elif urlparse(source).path.endswith(('.sh','.txt')):
            candidates.update(ipk_links(download(source,512*1024).decode('utf-8','replace')))
    if len(candidates)!=1:
        raise ValueError('المصدر لا يحتوي رابط IPK واحدًا مباشرًا. هذه الإضافة تحتاج تجهيز حزمة خاصة؛ لم يُشغّل أي سكربت.')
    url=candidates.pop()
    raw=download(url,32*1024*1024)
    check_install_hooks(raw)
    meta={key:value.strip() for key,value in package_metadata(raw).items()}
    if not all(meta.get(k) for k in ('Package','Version','Architecture')):
        raise ValueError('بيانات اسم الحزمة أو إصدارها أو معماريتها ناقصة')
    arch=meta['Architecture'].lower()
    machine=info['arch']
    accepted=(arch in ('all','noarch') or arch==machine or
              (machine=='armv7l' and arch.startswith('armv7')) or
              (machine=='aarch64' and arch.startswith('aarch64')) or
              (machine in ('mips','mipsel') and arch.startswith('mipsel')))
    if not accepted or re.search(r'\bpython(?:2|-core)\b',meta.get('Depends','')):
        raise ValueError('معمارية الحزمة أو Python لا يناسب هذا الجهاز')
    return dict(id=meta['Package'],name=item['name'],version=meta['Version'],category=item['category'],
                description=item['description'],url=url,sha256=hashlib.sha256(raw).hexdigest(),
                architectures=[machine],images=['openatv'],python_major=[3],
                upstream_review='Metadata only; runtime compatibility untested')
