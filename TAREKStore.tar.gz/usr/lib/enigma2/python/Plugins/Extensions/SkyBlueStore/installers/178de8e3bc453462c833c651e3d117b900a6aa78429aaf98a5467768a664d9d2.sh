#!/bin/sh
# BlackNeon XP FHD skin (3 posters, with background) by Ismail Elkhooly - installer
URL="https://raw.githubusercontent.com/ismailelkhooly/Ismail-/main/SKIN-BLACKNEON-XP-FHD-3postrs-with_background_by_ismail_elkhooly-2025.tar.gz"
TMP="/tmp/blackneon_skin.tar.gz"
SKIN="/usr/share/enigma2/BLACKNEON-XP-FHD"

echo "> BlackNeon XP FHD skin installer"
rm -f "$TMP"
echo "> Downloading..."
wget -q --no-check-certificate -O "$TMP" "$URL"
if [ ! -s "$TMP" ] || ! tar -tzf "$TMP" >/dev/null 2>&1; then
    echo "> Download failed."
    rm -f "$TMP"
    exit 1
fi
echo "> Removing old version..."
rm -rf "$SKIN"
echo "> Installing..."
if ! tar -xzf "$TMP" -C /; then
    echo "> Install failed."
    rm -f "$TMP"
    exit 1
fi
rm -f "$TMP"
sync
echo "> BlackNeon XP FHD installed. Choose it in the skin menu and restart the GUI."
exit 0
