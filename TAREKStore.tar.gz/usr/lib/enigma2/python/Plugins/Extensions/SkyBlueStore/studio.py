"""Three lightweight card layouts sharing the verified Store install workflow."""
import os
import re
from xml.sax.saxutils import escape
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ActionMap import ActionMap
from enigma import getDesktop
from .plugin import SkyBlueStore, BASE
from .layout import fullscreen
from .core import installed_version
from .script_metadata import display_metadata, entry_prefix
from .sections import subgroup
from .navigation import card_target,page_target
from .library import collection_cards
from .brand import BRAND, enrich
from .card_styles import surface
from Screens.ChoiceBox import ChoiceBox

THEMES=('AURORA','OBSIDIAN GOLD','SOLAR GOLD')
CONFIG='/etc/enigma2/skyblue-store-theme'


def item_icon(item):
    if item.get('collection'):
        path=os.path.join(BASE,'assets','groups',item['id']+'.png')
    else:
        path=os.path.join(BASE,'assets','apps',item['id']+'.png')
    if not os.path.isfile(path):
        from .script_metadata import group_icon
        path=os.path.join(BASE,'assets',(item.get('icon') or group_icon(subgroup(item),item['category']))+'.png')
    return path


def current_theme():
    try:return int(open(CONFIG).read().strip())%3
    except (OSError,ValueError):return 0


def geometry(theme):
    # Six equal cards: no detached strip, empty slots, or hidden navigation rows.
    x0=(28,28,28)[theme]; gap=(18,20,22)[theme]
    width=(250,248,246)[theme]
    return [(x0+c*(width+gap),174+r*205,width,187) for r in range(2) for c in range(3)]


def studio_skin(theme):
    accent=('#40d9ef','#e9c474','#ffd779')[theme]
    parts=['<screen position="0,0" size="1200,660" flags="wfNoBorder" backgroundColor="%s">'%('#20170d' if theme==2 else '#090e17')]
    def label(name,x,y,w,h,size,color='#edf4ff',align='left'):
        parts.append('<widget name="%s" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="%s" halign="%s" transparent="1" zPosition="3" />'%(name,x,y,w,h,size,color,align))
    def pixmap(name,x,y,w,h,z=2):
        parts.append('<widget name="%s" position="%d,%d" size="%d,%d" alphatest="blend" scale="1" zPosition="%d" />'%(name,x,y,w,h,z))
    parts.append('<eLabel position="28,82" size="1144,2" backgroundColor="%s" />'%accent)
    label('brand',28,20,620,46,31,accent)
    label('device',736,31,436,30,17,'#93a6bd','right')
    parts.append('<eLabel position="28,65" size="650,16" text="Designed by Mohammed Al-Fatlawi" font="Regular;12" foregroundColor="#b8c9dc" transparent="1" zPosition="3" />')
    label('category',28,100,790,40,22,accent,'right')
    parts.append('<eLabel position="840,100" size="332,43" text="الأزرق: تحديث أونلاين" font="Regular;20" halign="center" valign="center" backgroundColor="#204c70" foregroundColor="#eff8ff" zPosition="3" />')
    label('rail',28,141,790,25,15,'#93a6bd','right')
    parts.append('<widget name="list" position="0,0" size="1,1" itemHeight="1" font="Regular;1" scrollbarMode="showNever" zPosition="-2" />')
    parts.append('<ePixmap position="840,174" size="332,392" pixmap="%s/assets/%s" scale="1" zPosition="0" />'%(BASE,'detail-panel-gold.png' if theme==2 else 'detail-panel.png'))
    pixmap('app_icon',950,194,112,112)
    label('name',860,319,292,63,25,'#ffffff','center')
    label('state',872,389,268,28,18,'#53e6ae','center')
    pixmap('installed_badge',852,391,20,20)
    label('release',860,430,292,40,16,accent,'right')
    label('author',860,472,292,38,16,'#b8c9dc','right')
    label('description',860,513,292,44,15,'#a6bbd1','right')
    label('status',28,586,1144,28,18,accent,'right')
    label('footer',28,625,1144,27,15,'#b8c9dc','center')
    for i,(x,y,w,h) in enumerate(geometry(theme)):
        pixmap('tile%d'%i,x,y,w,h)
        pixmap('icon%d'%i,x+16,y+18,66,66)
        label('meta%d'%i,x+92,y+21,w-108,25,16,'#d6e6fa','right')
        label('hint%d'%i,x+92,y+53,w-108,24,13,'#9fb6ce','right')
        label('title%d'%i,x+16,y+101,w-32,70,21,'#ffffff','right')
    # Yellow opens an opaque right-side category chooser. Left returns to cards.
    pixmap('nav_panel',840,166,340,424,8)
    label('nav_labels',858,181,304,38,21,accent,'right')
    pixmap('nav_focus',852,224,316,29,9)
    for i in range(12):
        parts.append('<widget name="nav%d" position="866,%d" size="287,28" font="Regular;18" halign="right" foregroundColor="#edf5ff" transparent="1" zPosition="10" />'%(i,224+i*29))
    parts=[p.replace('zPosition="3"','zPosition="10"') if 'name="nav_labels"' in p else p for p in parts]
    return ''.join(parts)+'</screen>'


class StoreStudio(SkyBlueStore):
    def __init__(self,session,theme=None,category=None,state=None):
        self.theme=current_theme() if theme is None else theme
        self.cards_ready=False
        self.saved_positions={}
        self.painted_page=None
        self.browse_level=(state or {}).get('level','categories')
        self.start_state=state or {}
        self.nav_focus=False;self.nav_index=0
        self.skin=studio_skin(self.theme)
        # Parent uses type(self).skin; supply a per-instance generated template.
        type(self).skin=self.skin
        super().__init__(session,initial_category=category)
        self['nav_panel']=Pixmap();self['nav_labels']=Label('')
        self['nav_focus']=Pixmap()
        for i in range(12):self['nav%d'%i]=Label('')
        self['brand']=Label('SKY BLUE STORE  /  '+THEMES[self.theme])
        self['footer']=Label('OK فتح  |  الأصفر الأقسام  |  الأزرق تحديث البنل  |  EXIT رجوع  |  INFO تفاصيل  |  MENU إعدادات')
        self['rail']=Label('')
        for i in range(len(geometry(self.theme))):
            self['tile%d'%i]=Pixmap();self['icon%d'%i]=Pixmap()
            self['title%d'%i]=Label('');self['meta%d'%i]=Label('');self['hint%d'%i]=Label('')
        self['actions']=ActionMap(['OkCancelActions','DirectionActions','ColorActions','MenuActions','InfoActions','ChannelSelectBaseActions'],{
            'cancel':self.leave,'ok':self.confirm,'green':self.confirm,'yellow':self.choose_category,'blue':self.online_update,
            'menu':self.open_settings,'info':self.show_source_details,
            'red':self.choose_group,'nextBouquet':lambda:self.move_page(1),'prevBouquet':lambda:self.move_page(-1),
            'left':lambda:self.move_card('left'),'right':lambda:self.move_card('right'),
            'up':lambda:self.move_card('up'),'down':lambda:self.move_card('down')},-1)
        self.onLayoutFinish.append(self.card_ready)

    def columns(self):return 3
    def loaded(self,items):
        super().loaded(sorted(enrich(items,BASE),key=lambda item:(item['category'],subgroup(item),bool(item.get('pending_review')),item['name'].casefold())))
        if self.start_state:
            self.subcategory_filter=self.start_state.get('group')
            self.render()
            if self['list'].list:self['list'].moveToIndex(min(self.start_state.get('index',0),len(self['list'].list)-1))
    def render(self):
        self.painted_page=None
        if self.browse_level=='apps':super().render()
        else:
            category=self.categories[self.category_index] if self.browse_level=='groups' else None
            cards=collection_cards(self.store_items,category)
            self['list'].setList([(item['name'],item) for item in cards]);self.selected()
    def choose_category(self):
        if self.busy:return
        self.nav_focus=not self.nav_focus
        if self.nav_focus:
            self.nav_categories=[card['target_category'] for card in collection_cards(self.store_items)]
            if not self.nav_categories:self.nav_focus=False;return
            current=self.categories[self.category_index]
            self.nav_index=self.nav_categories.index(current) if current in self.nav_categories else 0
        self.paint_navigation()
    def show_categories(self):
        self.remember_position()
        self.browse_level='categories';self.subcategory_filter=None
        self.render();self.restore_position()
    def paint_navigation(self):
        if not self.cards_ready:return
        if not self.nav_focus:
            for name in ['nav_panel','nav_labels','nav_focus']+['nav%d'%i for i in range(12)]:self[name].hide()
            return
        self['nav_panel'].instance.setPixmapFromFile(os.path.join(BASE,'assets','detail-panel-gold.png' if self.theme==2 else 'detail-panel.png'))
        self['nav_labels'].setText('الأقسام • اختر ثم OK')
        for i in range(12):
            label=self['nav%d'%i]
            if i>=len(self.nav_categories):label.hide();continue
            category=self.nav_categories[i]
            title='OSCam / السوفتكام' if category=='مشغلات الخدمة' else category
            label.setText(title);label.show()
        from enigma import ePoint
        size=getDesktop(0).size()
        self['nav_focus'].instance.setPixmapFromFile(os.path.join(BASE,'assets','nav-selection.png'))
        self['nav_focus'].instance.move(ePoint(round(852*size.width()/1200),round((224+self.nav_index*29)*size.height()/660)))
        self['nav_focus'].show()
        self['nav_panel'].show();self['nav_labels'].show()
    def category_chosen(self,choice):
        super().category_chosen(choice)
        if choice:self.restore_position()
    def remember_position(self):
        self.saved_positions[(self.browse_level,self.categories[self.category_index] if self.browse_level!='categories' else '',self.subcategory_filter)]=self['list'].getSelectionIndex()
    def restore_position(self):
        index=self.saved_positions.get((self.browse_level,self.categories[self.category_index] if self.browse_level!='categories' else '',self.subcategory_filter),0)
        rows=self['list'].list
        if rows:self['list'].moveToIndex(min(index,len(rows)-1))
    def choose_group(self):
        if self.busy:return
        if self.browse_level=='categories':return
        if self.categories[self.category_index]==BRAND:return self.show_categories()
        self.remember_position();self.browse_level='groups';self.subcategory_filter=None
        self.render();self.restore_position()
    def confirm(self):
        if self.busy:return
        if self.nav_focus:
            self.remember_position()
            category=self.nav_categories[self.nav_index]
            self.nav_focus=False;self.paint_navigation()
            self.category_index=self.categories.index(category)
            self.browse_level='apps' if category==BRAND else 'groups';self.subcategory_filter=None
            self.render();self.restore_position();return
        row=self['list'].getCurrent()
        if not row:return
        item=row[1]
        if not item.get('collection'):return super().confirm()
        self.remember_position()
        self.category_index=self.categories.index(item['target_category'])
        self.subcategory_filter=item['target_group']
        self.browse_level='apps' if self.subcategory_filter or item['target_category']==BRAND else 'groups'
        self.render();self.restore_position()
    def check_selected_update(self):
        row=self['list'].getCurrent()
        if row and row[1].get('collection'):return self.confirm()
        super().check_selected_update()
    def leave(self):
        if self.busy:return super().leave()
        if self.nav_focus:
            self.nav_focus=False;self.paint_navigation();return
        if self.browse_level=='apps':
            if self.categories[self.category_index]==BRAND:return self.show_categories()
            return self.choose_group()
        if self.browse_level=='groups':return self.show_categories()
        super().leave()
    def group_chosen(self,choice):
        if not choice or not self.alive:return
        self.remember_position();self.subcategory_filter=choice[1]
        self.render();self.restore_position()
    def card_ready(self):self.cards_ready=True;self.draw_cards();self.paint_navigation()
    def selected(self):
        row=self['list'].getCurrent()
        if row and row[1].get('collection'):
            item=row[1]
            self['name'].setText(item['name']);self['author'].setText('قسم مستقل' if self.browse_level=='categories' else 'مجموعة داخل القسم')
            self['release'].setText(item['subtitle']);self['state'].setText('OK • فتح')
            self['description'].setText(item['description']);self['status'].setText('الأسهم: تنقل • OK: فتح')
            self['installed_badge'].hide()
            if self['app_icon'].instance is not None:self['app_icon'].instance.setPixmapFromFile(item_icon(item))
            if self.cards_ready and self.alive:self.draw_cards()
            return
        super().selected()
        if self.alive:
            row=self['list'].getCurrent()
            if row:
                item=row[1]
                version=installed_version(item,self.package_state)
                self['description'].setText(re.sub(r'\s+',' ',item.get('description','')).strip()[:110] or subgroup(item))
                self['status'].setText('غير متاحة حاليًا' if item.get('pending_review') else 'OK • إعادة التثبيت' if version is not None else 'OK • تنزيل وتثبيت')
        if self.cards_ready and self.alive:self.draw_cards()
    def move_card(self,direction):
        if self.busy:return
        if self.nav_focus:
            if direction in ('up','down'):
                self.nav_index=(self.nav_index+(-1 if direction=='up' else 1))%len(self.nav_categories)
            else:self.nav_focus=False
            self.paint_navigation();return
        rows=self['list'].list
        if rows:self['list'].moveToIndex(card_target(self.theme,self['list'].getSelectionIndex(),len(rows),direction))
    def move_page(self,step):
        if self.busy:return
        rows=self['list'].list
        if rows:self['list'].moveToIndex(page_target(self.theme,self['list'].getSelectionIndex(),len(rows),step))
    def draw_cards(self):
        rows=self['list'].list
        count=len(geometry(self.theme))
        current=self['list'].getSelectionIndex();start=(current//count)*count
        signature=(self.browse_level,start,self.categories[self.category_index],self.subcategory_filter,len(rows))
        refresh=self.painted_page!=signature
        heading='الأقسام الرئيسية' if self.browse_level=='categories' else self.categories[self.category_index]+(' / '+self.subcategory_filter if self.subcategory_filter else ' / المجموعات')
        self['category'].setText(heading+'   ·   صفحة %d / %d'%(current//count+1,max(1,(len(rows)+count-1)//count)))
        self['rail'].setText(('اختر القسم' if self.browse_level=='categories' else 'اختر المجموعة' if self.browse_level=='groups' else 'اختر الإضافة')+'  ·  %d عنصر  ·  الأسهم للتنقل'%len(rows))
        for i in range(count):
            widgets=[self['tile%d'%i],self['icon%d'%i],self['title%d'%i],self['meta%d'%i],self['hint%d'%i]]
            if start+i>=len(rows):
                for widget in widgets:widget.hide()
                continue
            for widget in widgets:widget.show()
            item=rows[start+i][1];version=installed_version(item,self.package_state)
            self['tile%d'%i].instance.setPixmapFromFile(os.path.join(BASE,'assets',surface(item,self.theme,current==start+i)))
            if not refresh:continue
            self['icon%d'%i].instance.setPixmapFromFile(item_icon(item))
            title=re.sub(r'\s*\([^)]*\)','',item['name']).strip()
            limit=46
            self['title%d'%i].setText(entry_prefix(item,version,self.update_flags.get(item['id']))+(title[:limit-1]+'…' if len(title)>limit else title))
            author=item.get('script_author') or item.get('author') or 'المصدر غير محدد'
            self['meta%d'%i].setText(item['subtitle'] if item.get('collection') else str(item.get('version') or item.get('source_version') or ''))
            self['hint%d'%i].setText('فتح المجموعة' if item.get('collection') else author[:18])
        self.painted_page=signature
    def online_update(self):
        if self.busy:return
        from .update_screen import StoreOnlineUpdate
        self.session.open(StoreOnlineUpdate)
    def open_settings(self):
        if self.busy:return
        from .preferences import menu_visible
        choices=[('تحديث البنل أونلاين','update'),
                 ('الظهور في المنيو الرئيسي: '+('ظاهر' if menu_visible() else 'مخفي')+' — تبديل','visibility'),
                 ('تغيير التصميم: '+THEMES[self.theme],'theme'),
                 ('فحص تحديث الإضافة المحددة','app-update')]
        self.session.openWithCallback(self.settings_chosen,ChoiceBox,title='إعدادات Sky Blue Store',list=choices)
    def settings_chosen(self,choice):
        if not choice or not self.alive:return
        action=choice[1]
        if action=='update':return self.online_update()
        if action=='theme':return self.switch_theme()
        if action=='app-update':return self.check_selected_update()
        if action=='visibility':
            from .preferences import menu_visible,set_menu_visible
            try:
                visible=not menu_visible();set_menu_visible(visible)
                self['status'].setText('تم إظهار البنل في المنيو الرئيسي.' if visible else 'تم إخفاء البنل من المنيو الرئيسي. يبقى متاحًا من قائمة البلجنات.')
            except OSError as error:self['status'].setText('تعذّر حفظ الإعداد: '+str(error))
    def switch_theme(self):
        if self.busy:return
        theme=(self.theme+1)%3
        with open(CONFIG,'w') as stream:stream.write(str(theme))
        self.close(('theme',theme,self.categories[self.category_index],dict(level=self.browse_level,group=self.subcategory_filter,index=self['list'].getSelectionIndex())))


def open_studio(session,theme=None,category=None,state=None):
    def closed(result=None):
        if isinstance(result,tuple) and result[0]=='theme':open_studio(session,result[1],result[2],result[3])
    session.openWithCallback(closed,StoreStudio,theme,category,state)
