#!/bin/sh
# Permanent Sky Blue Scan installer; the manifest selects the current release.
set -eu
command -v python3 >/dev/null 2>&1 || { echo 'ERROR: Python 3 is required.'; exit 1; }
command -v opkg >/dev/null 2>&1 || { echo 'ERROR: Run this on an Enigma2 receiver.'; exit 1; }
[ "$(id -u)" = 0 ] || { echo 'ERROR: Root access is required.'; exit 1; }
[ "$#" = 0 ] || { echo 'ERROR: This installer does not need an activation code.'; exit 1; }
exec python3 - <<'SKYBLUE_SCAN_PY'
import hashlib, json, os, re, shutil, subprocess, tarfile, tempfile, uuid
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import build_opener, HTTPRedirectHandler

PACKAGE = 'enigma2-plugin-extensions-skybluescan'
BASE = 'https://updates.skyblue1.us/e2/'

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args):
        raise ValueError('Unexpected redirect; installation cancelled.')

def validate(m):
    version = m.get('version', '')
    if m.get('package') != PACKAGE or not isinstance(version, str) or not re.fullmatch(r'[0-9]{1,4}\.[0-9]{1,4}\.[0-9]{1,4}', version):
        raise ValueError('Invalid Sky Blue Scan release.')
    address = urlsplit(m.get('url', ''))
    expected = '/e2/' + PACKAGE + '_' + version + '_all.ipk'
    if address.scheme != 'https' or address.netloc != 'updates.skyblue1.us' or address.path != expected or address.query or address.fragment:
        raise ValueError('Untrusted package URL.')
    if type(m.get('size')) is not int or not 1 <= m['size'] <= 8388608 or not re.fullmatch('[a-f0-9]{64}', m.get('sha256', '')):
        raise ValueError('Invalid package size or checksum.')
    return tuple(map(int, version.split('.')))

def backup(plugin, enigma=Path('/etc/enigma2'), destination=Path('/home/root/skyblue-scan-backups')):
    paths = [plugin] if plugin.exists() else []
    for pattern in ('lamedb', 'lamedb5', 'bouquets.*', 'userbouquet.*.tv', 'userbouquet.*.radio', 'skybluescan*.json'):
        paths.extend(p for p in enigma.glob(pattern) if p.is_file())
    if not paths:
        return
    destination.mkdir(mode=0o700, parents=True, exist_ok=True)
    # A failed backup prevents installation; never change channel data here.
    target = destination / ('before-install-' + datetime.utcnow().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8] + '.tar.gz')
    required = sum(p.stat().st_size if p.is_file() else sum(x.stat().st_size for x in p.rglob('*') if x.is_file()) for p in paths)
    if shutil.disk_usage(destination).free < required + 2097152:
        raise ValueError('Not enough space for a rollback backup.')
    fd = os.open(str(target), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'wb') as output:
            with tarfile.open(fileobj=output, mode='w:gz', dereference=False) as archive:
                for item in dict.fromkeys(paths):
                    archive.add(str(item), arcname=str(item).lstrip('/'))
        print('Backup saved: ' + str(target))
    except Exception:
        target.unlink(missing_ok=True)
        raise

temporary = None
try:
    opener = build_opener(NoRedirect())
    with opener.open(BASE + 'scan-latest.json', timeout=25) as response:
        raw = response.read(16385)
    if len(raw) > 16384:
        raise ValueError('Release manifest is too large.')
    manifest = json.loads(raw)
    target_version = validate(manifest)
    result = subprocess.run(['opkg', 'status', PACKAGE], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    installed = re.search(r'^Version:\s*([0-9]+\.[0-9]+\.[0-9]+)\s*$', result.stdout.decode('utf-8','replace'), re.M)
    current_version = tuple(map(int, installed.group(1).split('.'))) if installed else (0,0,0)
    plugin = Path('/usr/lib/enigma2/python/Plugins/Extensions/SkyBlueScan')
    alternate = Path('/usr/lib64/enigma2/python/Plugins/Extensions/SkyBlueScan')
    if (alternate / 'plugin.py').exists():
        plugin = alternate
    repair = current_version == target_version and not (plugin / 'plugin.py').is_file()
    if current_version >= target_version and not repair:
        print('Sky Blue Scan is already up to date: ' + installed.group(1))
    else:
        print('Downloading Sky Blue Scan ' + manifest['version'] + '...')
        fd, temporary = tempfile.mkstemp(prefix='skyblue-scan-', suffix='.ipk')
        total, digest = 0, hashlib.sha256()
        with os.fdopen(fd, 'wb') as output:
            with opener.open(manifest['url'], timeout=25) as response:
                while True:
                    block = response.read(65536)
                    if not block:
                        break
                    total += len(block)
                    if total > manifest['size']:
                        raise ValueError('Package exceeds the declared size.')
                    digest.update(block)
                    output.write(block)
        if total != manifest['size'] or digest.hexdigest() != manifest['sha256']:
            raise ValueError('Package verification failed; nothing installed.')
        with open(temporary, 'rb') as stream:
            if stream.read(8) != b'!<arch>\n':
                raise ValueError('Invalid IPK package.')
        backup(plugin)
        command = ['opkg'] + (['--force-reinstall'] if repair else []) + ['install', temporary]
        if subprocess.run(command).returncode:
            raise ValueError('Installation failed; see opkg output above.')
        print('Installed Sky Blue Scan ' + manifest['version'])
    print('Done. Restart Enigma2 to load the plugin. Existing channel order is preserved.')
except Exception as error:
    print('ERROR: ' + str(error)[:250])
    raise SystemExit(1)
finally:
    if temporary and os.path.exists(temporary):
        os.unlink(temporary)
SKYBLUE_SCAN_PY
