#!/bin/sh
# IPtoSAT installer (zKhadiri) - https://github.com/zKhadiri/IPtoSAT
# Downloads the latest main branch from GitHub and copies the plugin to the box.

NAME="IPtoSAT"
PLUGIN="IPtoSAT"
URL="https://github.com/zKhadiri/IPtoSAT/archive/refs/heads/main.tar.gz"
TMPDIR="/tmp/zakaria_install"
ROOT="$TMPDIR/IPtoSAT-main"
DEST="/usr/lib/enigma2/python/Plugins/Extensions/$PLUGIN"

echo "> Installing $NAME please wait ..."
rm -rf "$TMPDIR"
mkdir -p "$TMPDIR" || exit 1

wget -q -O "$TMPDIR/src.tar.gz" "$URL" >/dev/null 2>&1
if [ ! -s "$TMPDIR/src.tar.gz" ]; then
    wget -q --no-check-certificate -O "$TMPDIR/src.tar.gz" "$URL" >/dev/null 2>&1
fi
if [ ! -s "$TMPDIR/src.tar.gz" ]; then
    rm -rf "$TMPDIR"
    echo "> Download failed, $NAME was NOT installed"
    exit 1
fi
if ! tar -xzf "$TMPDIR/src.tar.gz" -C "$TMPDIR" >/dev/null 2>&1; then
    rm -rf "$TMPDIR"
    echo "> Extract failed, $NAME was NOT installed"
    exit 1
fi
if [ ! -f "$ROOT/src/$PLUGIN/plugin.py" ]; then
    rm -rf "$TMPDIR"
    echo "> Wrong archive, $NAME was NOT installed"
    exit 1
fi

rm -rf "$DEST"
mkdir -p "$DEST"
cp -rf "$ROOT/src/$PLUGIN/." "$DEST/"
# settings files: only added when missing, so your lists are kept
mkdir -p /etc/enigma2
for f in iptosat.conf iptosat.json; do
    [ -f "/etc/enigma2/$f" ] || cp -f "$ROOT/src/etc/enigma2/$f" "/etc/enigma2/$f"
done

rm -rf "$TMPDIR"
if [ ! -f "$DEST/plugin.py" ]; then
    echo "> Install check failed, $NAME was NOT installed"
    exit 1
fi
sync
echo "> $NAME installed successfully"
echo "> Please restart the GUI"
exit 0
