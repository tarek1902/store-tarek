#!/bin/sh
# ==============================================================================
# SkyBlue Signal Pro - Universal Telnet Installer & Updater
# Version: 1.3.0
# Command: wget -q "--no-check-certificate" https://updates.skyblue1.us/e2/install-signal.sh -O - | /bin/sh
#      or: curl -k -s https://updates.skyblue1.us/e2/install-signal.sh | /bin/sh
# ==============================================================================

set -e

VERSION="1.3.0"
TAR_URL="https://updates.skyblue1.us/e2/signal/SkyBlueSignal.tar.gz"
EXT_DIR="/usr/lib/enigma2/python/Plugins/Extensions"
PLUGIN_DIR="$EXT_DIR/SkyBlueSignal"
ARCHIVE="/tmp/SkyBlueSignal.tar.gz"

echo ""
echo "=========================================================="
echo "    👑 SkyBlue Signal Pro v$VERSION Installation"
echo "    Next-Gen Satellite Signal Cockpit (Pure Black OLED)"
echo "=========================================================="
echo ""

# 1. Download fresh package from server
echo "[*] Downloading SkyBlue Signal Pro package from server..."
rm -f "$ARCHIVE" 2>/dev/null || true

DOWNLOADED=0
if command -v curl >/dev/null 2>&1; then
    if curl -k -L --fail --max-time 60 -o "$ARCHIVE" "$TAR_URL"; then
        DOWNLOADED=1
    fi
fi

if [ "$DOWNLOADED" != "1" ] && command -v wget >/dev/null 2>&1; then
    if wget --no-check-certificate -q -O "$ARCHIVE" "$TAR_URL"; then
        DOWNLOADED=1
    fi
fi

if [ "$DOWNLOADED" != "1" ] || [ ! -f "$ARCHIVE" ] || [ ! -s "$ARCHIVE" ]; then
    echo "[!] Server download failed. Checking local storage fallback..."
    if [ -f "/media/hdd/SkyBlueSignal.tar.gz" ]; then
        cp -f "/media/hdd/SkyBlueSignal.tar.gz" "$ARCHIVE" 2>/dev/null || true
    fi
    if [ ! -f "$ARCHIVE" ] || [ ! -s "$ARCHIVE" ]; then
        echo "[!] Error: Failed to download package and no local archive found."
        exit 1
    fi
fi

python3 - <<'VERIFY_SIGNAL'
import hashlib,tarfile,pathlib
p='/tmp/SkyBlueSignal.tar.gz'
if hashlib.sha256(open(p,'rb').read()).hexdigest()!='74fb99c14866e572b4aad476e8698eee287336420347c2cfd581b2b631ecb349':raise SystemExit('Signal archive checksum mismatch')
with tarfile.open(p) as a:
 for m in a.getmembers():
  parts=pathlib.PurePosixPath(m.name)
  if parts.is_absolute() or '..' in parts.parts or not parts.parts or parts.parts[0]!='SkyBlueSignal' or not (m.isfile() or m.isdir()):raise SystemExit('Unsafe archive path')
VERIFY_SIGNAL

# 2. Local Backup to HDD / USB for offline multi-boot use
mkdir -p /media/hdd/SkyBlueScreenshots 2>/dev/null || true
if [ -d "/media/hdd" ] && [ -w "/media/hdd" ]; then
    cp -f "$ARCHIVE" /media/hdd/SkyBlueSignal.tar.gz 2>/dev/null || true
fi

# 3. Clean previous install and extract
echo "[*] Installing to $PLUGIN_DIR ..."
mkdir -p "$EXT_DIR"
rm -rf "$PLUGIN_DIR"/*.pyc "$PLUGIN_DIR"/__pycache__ 2>/dev/null || true
tar -xzf "$ARCHIVE" -C "$EXT_DIR/"
rm -rf "$PLUGIN_DIR"/*.pyc "$PLUGIN_DIR"/__pycache__ 2>/dev/null || true
rm -f "$ARCHIVE" 2>/dev/null || true


echo 'Done. Restart the GUI from the receiver menu when ready.'
