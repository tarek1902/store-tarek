"""Scale a borderless TV layout to the receiver's actual GUI resolution."""
import xml.etree.ElementTree as ET


def fullscreen(xml, width, height):
    root = ET.fromstring(xml)
    sx, sy = width / 1200.0, height / 660.0
    root.set('position', '0,0')
    root.set('size', '%d,%d' % (width,height))
    root.set('flags', 'wfNoBorder')
    for element in root:
        for attribute in ('position','size'):
            if attribute in element.attrib:
                x,y = map(int,element.get(attribute).split(','))
                element.set(attribute,'%d,%d' % (round(x*sx),round(y*sy)))
        if element.get('font'):
            name,size = element.get('font').split(';')
            element.set('font','%s;%d' % (name,round(int(size)*min(sx,sy))))
        if element.get('itemHeight'):
            element.set('itemHeight',str(round(int(element.get('itemHeight'))*sy)))
        if element.tag == 'ePixmap' or element.get('alphatest'):
            element.set('scale','1')
    return ET.tostring(root,encoding='unicode')
