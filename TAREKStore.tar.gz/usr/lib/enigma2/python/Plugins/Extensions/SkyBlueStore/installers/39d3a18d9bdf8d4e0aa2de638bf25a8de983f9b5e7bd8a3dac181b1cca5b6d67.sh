#!/bin/sh
# Levi45 Free Server installer - https://github.com/levi-45/Levi45FreeServer

NAME="Levi45FreeServer"
URL="https://github.com/levi-45/Levi45FreeServer/archive/refs/heads/main.tar.gz"
TMPDIR="/tmp/${NAME}_install"
PLUGINPATH="/usr/lib/enigma2/python/Plugins/Extensions/$NAME"

echo "> Installing $NAME please wait ..."
rm -rf "$TMPDIR"
mkdir -p "$TMPDIR" || exit 1

wget -q -O "$TMPDIR/main.tar.gz" "$URL" >/dev/null 2>&1
if [ ! -s "$TMPDIR/main.tar.gz" ]; then
    wget -q --no-check-certificate -O "$TMPDIR/main.tar.gz" "$URL" >/dev/null 2>&1
fi
if [ ! -s "$TMPDIR/main.tar.gz" ]; then
    rm -rf "$TMPDIR"
    echo "> Download failed, $NAME was NOT installed"
    exit 1
fi

if ! tar -xzf "$TMPDIR/main.tar.gz" -C "$TMPDIR" >/dev/null 2>&1; then
    rm -rf "$TMPDIR"
    echo "> Extract failed, $NAME was NOT installed"
    exit 1
fi

SRC="$TMPDIR/$NAME-main/usr/lib/enigma2/python/Plugins/Extensions/$NAME"
if [ ! -f "$SRC/plugin.py" ]; then
    rm -rf "$TMPDIR"
    echo "> Wrong archive, $NAME was NOT installed"
    exit 1
fi

rm -rf "$PLUGINPATH"
mkdir -p "$(dirname "$PLUGINPATH")"
cp -rf "$SRC" "$PLUGINPATH"
rm -rf "$TMPDIR"

if [ ! -f "$PLUGINPATH/plugin.py" ]; then
    echo "> Install check failed, $NAME was NOT installed"
    exit 1
fi

sync
echo "> $NAME installed successfully"
echo "> Please restart the GUI"
exit 0
