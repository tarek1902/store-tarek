#!/bin/sh
# IPAudioPro 1.7 installer (zKhadiri) - https://github.com/zKhadiri/IPAudioPro-Releases-
# Picks the right .ipk for this box (cpu, Python, FFmpeg) from the v1.7 folder.

VERSION="1.7"
PKG="enigma2-plugin-extensions-ipaudiopro"
BASE="https://raw.githubusercontent.com/zKhadiri/IPAudioPro-Releases-/refs/heads/main/v$VERSION"
TMPFILE="/tmp/ipaudiopro.ipk"

echo "> Installing IPAudioPro $VERSION please wait ..."

if [ -f /var/lib/dpkg/status ]; then
    echo "> IPAudioPro has no DreamOS package"
    exit 1
fi

# Python version (x.y)
if command -v python3 >/dev/null 2>&1; then
    PY=$(python3 --version 2>&1 | awk '{print $2}' | cut -d. -f1-2)
else
    PY=$(python --version 2>&1 | awk '{print $2}' | cut -d. -f1-2)
fi
if [ -z "$PY" ]; then
    echo "> Python not found"
    exit 1
fi
echo "> Python: $PY"

# FFmpeg version, install it when missing
if ! opkg status ffmpeg 2>/dev/null | grep '^Version:' >/dev/null; then
    echo "> Installing ffmpeg ..."
    opkg update >/dev/null 2>&1
    opkg install ffmpeg >/dev/null 2>&1
fi
FF=$(opkg status ffmpeg 2>/dev/null | grep -i '^Version:' | awk '{print $2}' | cut -d. -f1)
FF=${FF##*:}
case "$FF" in
    4) FFV="4.4.3" ;;
    6) FFV="6.1" ;;
    7) FFV="7.1" ;;
    8) FFV="8.0" ;;
    *) echo "> FFmpeg version '$FF' is not supported"; exit 1 ;;
esac
echo "> FFmpeg: $FFV"

# cpu
ARCHS=""
case "$(uname -m)" in
    aarch64*) DIR="aarch64"; ARCHS="aarch64" ;;
    mips*) DIR="mipsel"; ARCHS="mips32el" ;;
    arm*)
        DIR="arm"
        FEEDS=$(ls /etc/opkg/ 2>/dev/null)
        for a in cortexa15hf-neon-vfpv4 cortexa9hf-neon cortexa7hf-vfp armv7ahf-vfp-neon armv7ahf-neon; do
            case "$FEEDS" in
                *"$a"*) ARCHS="$ARCHS $a" ;;
            esac
        done
        case "$ARCHS" in *armv7ahf-neon*) ;; *) ARCHS="$ARCHS armv7ahf-neon" ;; esac
        ;;
    *) echo "> CPU $(uname -m) is not supported"; exit 1 ;;
esac

# download the first file that exists for this box
rm -f "$TMPFILE"
FOUND=""
for a in $ARCHS; do
    FILE="${PKG}_${VERSION}_${a}_py${PY}_ff${FFV}.ipk"
    wget -q --no-check-certificate -O "$TMPFILE" "$BASE/python$PY/$DIR/$FILE" >/dev/null 2>&1
    if [ -s "$TMPFILE" ]; then
        FOUND="$FILE"
        break
    fi
    rm -f "$TMPFILE"
done
if [ -z "$FOUND" ]; then
    echo "> IPAudioPro $VERSION has no build for this box (python $PY, ffmpeg $FFV, $DIR)"
    exit 1
fi
echo "> Package: $FOUND"

# remove any other version first, then install this one
opkg remove "$PKG" >/dev/null 2>&1
opkg install --force-reinstall --force-overwrite --force-downgrade "$TMPFILE"
rm -f "$TMPFILE"

if ! opkg list-installed "$PKG" | grep "$VERSION" >/dev/null; then
    echo "> IPAudioPro $VERSION was NOT installed"
    exit 1
fi
sync
echo "> IPAudioPro $VERSION installed successfully"
echo "> Please restart the GUI"
exit 0
