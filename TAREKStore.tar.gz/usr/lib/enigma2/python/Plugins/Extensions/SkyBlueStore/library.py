"""Explicit category → group → app hierarchy; no mixed default library."""
import hashlib
from .sections import subgroup
from .brand import BRAND, branded, in_category
from .script_metadata import group_icon

ORDER=('البلجنات','السكنات','مشغلات الخدمة','الوسائط','القنوات','الأيقونات','الأدوات','النظام','النسخ والاستعادة')


def collection_cards(items,category=None):
    titles=sorted({subgroup(item) for item in items if in_category(item,category)}) if category else [c for c in ORDER if any(item['category']==c for item in items)]
    if not category:titles+=sorted({item['category'] for item in items}-set(ORDER))
    if not category and any(branded(item) for item in items):titles.insert(0,BRAND)
    result=[]
    for title in titles:
        members=[item for item in items if in_category(item,category) and subgroup(item)==title] if category else [item for item in items if in_category(item,title)]
        name='OSCam / السوفتكام' if title=='مشغلات الخدمة' else title
        key=(category or '')+'/'+title
        result.append(dict(id='collection-'+hashlib.sha256(key.encode()).hexdigest()[:16],name=name,category=category or title,
                           collection=True,target_category=category or title,target_group=title if category else None,
                           description='اختر المجموعة لعرض إضافاتها فقط' if category else 'افتح القسم ثم اختر المجموعة المناسبة',
                           subtitle=str(len(members))+' إضافة',icon='skyblue' if title==BRAND else group_icon(title,category or title)))
    return result
