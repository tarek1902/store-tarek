from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ActionMap import ActionMap
from twisted.internet import threads
from .online_update import inspect_update,apply_update

class StoreOnlineUpdate(Screen):
    skin='''<screen position="center,center" size="900,460" title="Sky Blue Store — تحديث أونلاين" backgroundColor="#111e2f">
      <eLabel position="30,26" size="840,48" text="SKY BLUE STORE / ONLINE UPDATE" font="Regular;30" foregroundColor="#edcb78" transparent="1" />
      <eLabel position="30,77" size="840,20" text="Designed by Mohammed Al-Fatlawi" font="Regular;15" foregroundColor="#b8c9dc" transparent="1" />
      <widget name="status" position="30,100" size="840,230" font="Regular;24" halign="right" foregroundColor="#edf5ff" transparent="1" />
      <eLabel position="30,386" size="840,44" text="الأخضر: تثبيت التحديث | الأزرق: فحص | EXIT: رجوع" font="Regular;22" foregroundColor="#79dacc" transparent="1" />
    </screen>'''
    def __init__(self,session):
        Screen.__init__(self,session)
        self.alive=True;self.busy=False;self.available=False
        self['status']=Label('جارٍ فحص التحديثات…')
        self['actions']=ActionMap(['OkCancelActions','ColorActions'],{'cancel':self.leave,'blue':self.check,'green':self.install,'ok':self.install},-1)
        self.onFirstExecBegin.append(self.check)
        self.onClose.append(self.closed)
    def closed(self):self.alive=False
    def leave(self):
        if not self.busy:self.close()
    def failed(self,error):
        if not self.alive:return
        self.busy=False
        self['status'].setText('تعذّر التحديث. يمكنك إعادة المحاولة.\n'+str(getattr(error,'value',error))[-1000:])
    def check(self):
        if self.busy:return
        self.busy=True;self.available=False;self['status'].setText('جارٍ فحص التحديثات…')
        threads.deferToThread(inspect_update).addCallbacks(self.checked,self.failed)
    def checked(self,result):
        if not self.alive:return
        self.busy=False;self.available=result['available']
        self['status'].setText('الإصدار المثبّت: '+result['current']+'\nآخر إصدار: '+result['latest']+'\n\n'+('يوجد تحديث جديد. اضغط الأخضر لتثبيته.' if self.available else 'لديك أحدث إصدار.'))
    def install(self):
        if self.busy or not self.available:return
        self.session.openWithCallback(self.confirmed,MessageBox,'تثبيت تحديث البنل؟ ستُحفظ نسخة رجوع قبل التحديث.',MessageBox.TYPE_YESNO,default=False)
    def confirmed(self,answer):
        if not answer or not self.alive:return
        self.busy=True;self.available=False
        self['status'].setText('جارٍ تنزيل التحديث وفحصه وتثبيته…\nلا تفصل الكهرباء عن الجهاز.')
        threads.deferToThread(apply_update).addCallbacks(self.installed,self.failed)
    def installed(self,result):
        if not self.alive:return
        self.busy=False
        self['status'].setText('تم تحديث البنل بنجاح.\nأعد تشغيل واجهة Enigma2 من قائمة الجهاز لتفعيل التحديث.')
