"""Display provenance without treating a shell script as an installable package."""
def display_metadata(item, installed=None):
    author=item.get('script_author') or item.get('author') or item.get('developer') or ('Sky Blue Team' if item.get('bundle') and 'skyblue' in item.get('id','') else 'غير محدد من المصدر')
    version=item.get('version') or item.get('source_version')
    release='الإصدار: '+str(version) if version else ''
    if installed is not None:release+=('  ·  ' if release else '')+'المثبّت: '+str(installed)
    return 'المطور: '+str(author),release


def entry_prefix(item, version=None, update=None):
    if update:return '↑  '
    if version is not None:return '✓  '
    return ''


def source_details(item):
    lines=[item['name'],item['category']+' / '+item.get('subcategory',''),'',item['description']]
    if item.get('script_author'):lines+=['','المطور / المجموعة: '+item['script_author']]
    if item.get('target_images'):lines+=['الصور المحددة: '+', '.join(item['target_images'])]
    if item.get('target_python_major'):lines+=['Python: '+', '.join(map(str,item['target_python_major']))]
    files=item.get('script_files',[])
    if files:lines+=['','ملفات المصدر ('+str(len(files))+'):',*files[:12]]
    urls=item.get('original_source_urls') or item.get('source_urls',[])
    if urls:lines+=['','روابط المصدر:',*urls[:4]]
    if item.get('script_sha256'):lines+=['','SHA256 للسكربت:',item['script_sha256']]
    if item.get('script_install'):lines+=['','يُجلب المثبّت ويعمل بالأمر بعد تأكيدك، مع عرض السجل. توفّر المصدر لا يثبت التوافق النهائي.']
    elif item.get('imported_script'):lines+=['','توفّر الرابط لا يثبت التوافق أو نجاح التشغيل.']
    return '\n'.join(lines)


def group_icon(title,category):
    for word,icon in [('الصوت','media'),('الرياضة','channels'),('الترجمة','plugins'),('البنلات','system'),('الأخبار','tools'),('الطقس','plugins'),('العربية','tools'),('الإشارة','channels'),('الملفات','tools'),('الشبكة','system'),('الصور','skins'),('السكن','skins'),('شعارات','picons'),('النسخ','backup')]:
        if word in title:return icon
    return {'السكنات':'skins','القنوات':'channels','الأيقونات':'picons','الوسائط':'media','النظام':'system','النسخ والاستعادة':'backup','مشغلات الخدمة':'service','الأدوات':'tools'}.get(category,'plugins')
