#!/bin/sh
# IPAudio installer (zKhadiri) - https://github.com/zKhadiri/IPAudio
# Downloads the latest main branch from GitHub and copies the plugin to the box.

NAME="IPAudio"
PLUGIN="IPAudio"
URL="https://github.com/zKhadiri/IPAudio/archive/refs/heads/main.tar.gz"
TMPDIR="/tmp/zakaria_install"
ROOT="$TMPDIR/IPAudio-main"
DEST="/usr/lib/enigma2/python/Plugins/Extensions/$PLUGIN"

echo "> Installing $NAME please wait ..."
rm -rf "$TMPDIR"
mkdir -p "$TMPDIR" || exit 1

wget -q -O "$TMPDIR/src.tar.gz" "$URL" >/dev/null 2>&1
if [ ! -s "$TMPDIR/src.tar.gz" ]; then
    wget -q --no-check-certificate -O "$TMPDIR/src.tar.gz" "$URL" >/dev/null 2>&1
fi
if [ ! -s "$TMPDIR/src.tar.gz" ]; then
    rm -rf "$TMPDIR"
    echo "> Download failed, $NAME was NOT installed"
    exit 1
fi
if ! tar -xzf "$TMPDIR/src.tar.gz" -C "$TMPDIR" >/dev/null 2>&1; then
    rm -rf "$TMPDIR"
    echo "> Extract failed, $NAME was NOT installed"
    exit 1
fi
if [ ! -f "$ROOT/src/$PLUGIN/plugin.py" ]; then
    rm -rf "$TMPDIR"
    echo "> Wrong archive, $NAME was NOT installed"
    exit 1
fi

rm -rf "$DEST"
mkdir -p "$DEST"
cp -rf "$ROOT/src/$PLUGIN/." "$DEST/"
# settings files: only added when missing
mkdir -p /etc/enigma2
[ -f /etc/enigma2/ipaudio.json ] || cp -f "$ROOT/src/etc/ipaudio.json" /etc/enigma2/ipaudio.json
[ -f /etc/asound.conf ] || cp -f "$ROOT/src/etc/asound.conf" /etc/asound.conf
# audio player for this box
case "$(uname -m)" in
    aarch64) ARCH=aarch64 ;;
    arm*) ARCH=arm ;;
    mips*) ARCH=mips ;;
    sh4) ARCH=sh4 ;;
    *) ARCH="" ;;
esac
if [ -n "$ARCH" ] && [ -f "$ROOT/player/$ARCH/gst1.0-ipaudio" ]; then
    cp -f "$ROOT/player/$ARCH/gst1.0-ipaudio" /usr/bin/gst1.0-ipaudio
    chmod 755 /usr/bin/gst1.0-ipaudio
else
    echo "> No IPAudio player for $(uname -m)"
fi

rm -rf "$TMPDIR"
if [ ! -f "$DEST/plugin.py" ]; then
    echo "> Install check failed, $NAME was NOT installed"
    exit 1
fi
sync
echo "> $NAME installed successfully"
echo "> Please restart the GUI"
exit 0
