#!/bin/sh
set -eu
umask 077
TASK=$(mktemp -d /tmp/skyblue-bootstrap.XXXXXX)
trap 'rm -f "$TASK/update.sh"; rmdir "$TASK"' EXIT
python3 - "$TASK/update.sh" <<'PY'
import hashlib,sys,urllib.request
url='https://updates.skyblue1.us/e2/subtitles-0.4.16/update.sh'
with urllib.request.urlopen(url,timeout=30) as response:
    if response.geturl()!=url: raise SystemExit('Unexpected redirect')
    raw=response.read(131073)
if len(raw)>131072 or hashlib.sha256(raw).hexdigest()!='0171a8bf232069080c8fd3908bf1877749b3a1a90303a9732fe4fb47e9eb8c7a':
    raise SystemExit('Updater checksum mismatch')
open(sys.argv[1],'wb').write(raw)
PY
/bin/sh "$TASK/update.sh"
