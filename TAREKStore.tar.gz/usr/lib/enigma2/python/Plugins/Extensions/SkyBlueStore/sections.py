def subgroup(item):
    if item.get('subcategory'):
        return item['subcategory']
    if item['category']=='البلجنات':
        return 'إضافات سكاي بلو' if item.get('bundle') else 'إضافات عامة'
    if item['category']=='الأدوات':
        name=item['name'].lower()
        if 'screenshot' in name:return 'التصوير والشاشة'
        if 'scan' in name:return 'البحث وتنظيم القنوات'
        return 'أدوات مساعدة'
    return 'مكتبات عامة'


def availability(item,image):
    targets=item.get('target_images') or ([] if item.get('reference_only') else item.get('images',[]))
    if targets:return 'مصنف لصورتك' if image in targets else 'مخصص لصورة أخرى'
    return 'التوافق يحتاج فحصًا'
