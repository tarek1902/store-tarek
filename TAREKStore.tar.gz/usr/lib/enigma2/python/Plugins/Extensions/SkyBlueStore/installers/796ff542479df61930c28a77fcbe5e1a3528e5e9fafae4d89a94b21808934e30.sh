#!/bin/sh
# WhatToWatch (Ahmed Mohammed Abbas) - installs the newest version from GitHub
# The repo has no installer of its own; this one downloads the main branch.

NAME="WhatToWatch"
REPO="https://github.com/Ahmed-Mohammed-Abbas/WhatToWatch"
RAW="https://raw.githubusercontent.com/Ahmed-Mohammed-Abbas/WhatToWatch/main"
DEST="/usr/lib/enigma2/python/Plugins/Extensions"
TARGET="$DEST/$NAME"
TMP="/tmp/${NAME}_install"
ARCHIVE="$TMP/main.tar.gz"

echo "> $NAME installer"
rm -rf "$TMP"
mkdir -p "$TMP" || exit 1

VER=$(wget -q --no-check-certificate -O - "$RAW/version.txt?t=$(date +%s)" 2>/dev/null | awk 'NR==1{gsub(/\r/,""); print}')
[ -n "$VER" ] && echo "> Newest version: $VER"

echo "> Downloading..."
wget -q --no-check-certificate -O "$ARCHIVE" "$REPO/archive/refs/heads/main.tar.gz"
if [ ! -s "$ARCHIVE" ]; then
    echo "> Download failed."
    rm -rf "$TMP"
    exit 1
fi

if ! tar -xzf "$ARCHIVE" -C "$TMP" >/dev/null 2>&1; then
    echo "> The download is damaged."
    rm -rf "$TMP"
    exit 1
fi
SRC="$TMP/$NAME-main"
if [ ! -f "$SRC/plugin.py" ]; then
    echo "> plugin.py not found in the download."
    rm -rf "$TMP"
    exit 1
fi
rm -rf "$SRC/.github"

echo "> Installing..."
rm -rf "$TARGET"
mkdir -p "$DEST"
if ! mv "$SRC" "$TARGET"; then
    echo "> Install failed."
    rm -rf "$TMP"
    exit 1
fi
rm -rf "$TMP"
sync

echo "> $NAME ${VER} installed. Please restart the GUI."
exit 0
