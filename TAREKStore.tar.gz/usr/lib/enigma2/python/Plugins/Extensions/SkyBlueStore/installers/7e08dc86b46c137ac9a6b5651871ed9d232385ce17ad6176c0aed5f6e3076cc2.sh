#!/bin/sh
# Stable Sky Blue installer: resolves latest.json and repairs audio dependencies.
set -eu
command -v python3 >/dev/null 2>&1 || { echo "ERROR: Python 3 is required."; exit 1; }
command -v opkg >/dev/null 2>&1 || { echo "ERROR: opkg is required."; exit 1; }
[ "$(id -u)" = "0" ] || { echo "ERROR: Run on the receiver as root."; exit 1; }
[ "$#" -le 1 ] || { echo "ERROR: Expected one optional activation code."; exit 1; }
exec python3 - "$@" <<'SKYBLUE_PY'
import hashlib,json,os,re,subprocess,sys,tempfile
from urllib.request import build_opener,HTTPRedirectHandler
from urllib.parse import urlsplit
class NoRedirect(HTTPRedirectHandler):
 def redirect_request(self,*args):raise ValueError('Unexpected redirect; installation cancelled.')
code=sys.argv[1] if len(sys.argv)>1 else None
if code is not None and not re.match(r'^[A-Za-z0-9_-]{4,50}$',code):raise SystemExit('ERROR: Invalid activation code.')
def find_plugin():
 candidates=['/usr/lib/enigma2/python/Plugins/Extensions/SkyBlue','/usr/lib64/enigma2/python/Plugins/Extensions/SkyBlue']
 try:
  files=subprocess.check_output(['opkg','files','enigma2-plugin-extensions-skyblue'],stderr=subprocess.DEVNULL).decode('utf-8','replace')
  for item in files.splitlines():
   item=item.strip()
   if item.startswith(('/usr/lib/','/usr/lib64/')) and item.endswith('/SkyBlue/activate_cli.py'):candidates.append(os.path.dirname(item))
 except (OSError,subprocess.CalledProcessError):pass
 return next((p for p in candidates if os.path.isfile(p+'/activate_cli.py') and os.path.isfile(p+'/client.py')),None)
path=None
try:
 opener=build_opener(NoRedirect())
 with opener.open('https://updates.skyblue1.us/e2/latest.json',timeout=25) as response:raw=response.read(16385)
 if len(raw)>16384:raise ValueError('Manifest too large.')
 m=json.loads(raw.decode('utf-8'));v=m.get('version','');url=urlsplit(m.get('url',''))
 if m.get('package')!='enigma2-plugin-extensions-skyblue' or not re.match(r'^\d{1,4}\.\d{1,4}\.\d{1,4}$',v):raise ValueError('Invalid Sky Blue release.')
 expected='/e2/enigma2-plugin-extensions-skyblue_'+v+'_all.ipk'
 if url.scheme!='https' or url.netloc!='updates.skyblue1.us' or url.path!=expected or url.query or url.fragment:raise ValueError('Untrusted package URL.')
 size=m.get('size');checksum=m.get('sha256','')
 if type(size) is not int or not 1<=size<=8388608 or not re.match(r'^[a-f0-9]{64}$',checksum):raise ValueError('Invalid size or checksum.')
 probe="import gi; gi.require_version('Gst','1.0'); from gi.repository import Gst; Gst.init([])"
 if subprocess.run(['python3','-c',probe],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15).returncode:
  print('Preparing Python GStreamer support from the receiver image feeds...')
  if subprocess.run(['opkg','update'],timeout=180).returncode:raise ValueError('Cannot update image package feeds. Check Internet and feed availability.')
  if subprocess.run(['opkg','install','python3-pygobject'],timeout=300).returncode:raise ValueError('Cannot install python3-pygobject from this image feed.')
 try:status=subprocess.check_output(['opkg','status','enigma2-plugin-extensions-skyblue'],stderr=subprocess.DEVNULL).decode('utf-8','replace')
 except subprocess.CalledProcessError:status=''
 installed=re.search(r'^Version:\s*(\S+)',status,re.M)
 installed=installed.group(1) if installed else ''
 installed_version=tuple(map(int,installed.split('.'))) if re.match(r'^\d+\.\d+\.\d+$',installed) else (0,0,0)
 target_version=tuple(map(int,v.split('.')))
 plugin=find_plugin()
 repair=installed_version==target_version and (plugin is None or (target_version>=(1,8,22) and not os.path.isfile(plugin+'/audio_requirements.py')))
 if installed_version<target_version or repair:
  print('Downloading Sky Blue E2 '+v+'...')
  fd,path=tempfile.mkstemp(prefix='skyblue-latest-',suffix='.ipk');digest=hashlib.sha256();total=0
  with os.fdopen(fd,'wb') as dest:
   with opener.open(m['url'],timeout=25) as response:
    while True:
     chunk=response.read(65536)
     if not chunk:break
     total+=len(chunk)
     if total>size:raise ValueError('Package exceeds declared size.')
     digest.update(chunk);dest.write(chunk)
  if total!=size or digest.hexdigest()!=checksum:raise ValueError('Package verification failed.')
  with open(path,'rb') as stream:
   if stream.read(8)!=b'!<arch>\n':raise ValueError('Invalid IPK file.')
  command=['opkg']+(['--force-reinstall'] if repair else [])+['install',path]
  if subprocess.run(command).returncode!=0:raise ValueError('Package installation failed; see opkg output above.')
 else:print('Sky Blue is already up to date: '+installed)
 plugin=find_plugin()
 if plugin and os.path.isfile(plugin+'/audio_requirements.py'):
  print('Checking and repairing audio requirements...')
  if subprocess.run(['python3',plugin+'/audio_requirements.py']).returncode:raise ValueError('Audio requirements are incomplete. See the setup message above.')
 if code is not None:
  print('Activating on this receiver. Device MAC and code will be sent to your panel.')
  plugin=find_plugin()
  if plugin is None:raise ValueError('Plugin files not found after installation. Check opkg files enigma2-plugin-extensions-skyblue.')
  bootstrap="import os,sys,types,runpy; root=sys.argv[1]; code=sys.argv[2]; package=types.ModuleType('_skyblue_installed'); package.__path__=[root]; package.__package__='_skyblue_installed'; sys.modules['_skyblue_installed']=package; sys.argv=['activate_cli','--code',code]; runpy.run_module('_skyblue_installed.activate_cli',run_name='__main__')"
  result=subprocess.run(['python3','-c',bootstrap,plugin,code])
  if result.returncode!=0:raise ValueError('Receiver activation failed. Check the message above; activation code is not repeated here.')
 print('Done. Restart Enigma2 from the receiver menu to load updated files.')
except Exception as error:
 print('ERROR: '+str(error)[:300]);sys.exit(1)
finally:
 if path and os.path.exists(path):os.unlink(path)
SKYBLUE_PY
