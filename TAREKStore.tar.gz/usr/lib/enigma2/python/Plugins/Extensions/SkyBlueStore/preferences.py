"""Small, atomic UI preferences; independent of activation and skin settings."""
import json
import os
PATH='/etc/enigma2/skyblue-store-settings.json'

def menu_visible(path=None):
    try:
        with open(path or PATH,encoding='utf-8') as stream:
            data=json.load(stream)
        return data.get('show_main_menu') is True
    except (OSError,ValueError,AttributeError):return False

def set_menu_visible(visible,path=None):
    path=path or PATH
    try:
        with open(path,encoding='utf-8') as stream:data=json.load(stream)
        if not isinstance(data,dict):data={}
    except (OSError,ValueError):data={}
    data['show_main_menu']=bool(visible)
    temporary=path+'.tmp'
    with open(temporary,'w',encoding='utf-8') as stream:json.dump(data,stream)
    os.chmod(temporary,0o600)
    os.replace(temporary,path)
