#!/bin/sh
# Multi-StalkerPro 1.2 installer (zKhadiri) - https://github.com/zKhadiri/MultiStalkerPro-releases
# Picks the right .ipk for this box (cpu, Python, image) from the v1.2 folder.

LABEL="1.2"
BASE="https://raw.githubusercontent.com/zKhadiri/MultiStalkerPro-releases/refs/heads/main"
TMPD="/tmp/msp_install"

# every package of this version: <python>/<cpu>/<image or ->/<file>
FILES="
3.12/aarch64/atv-pure-egami/enigma2-plugin-extensions-multi-stalkerpro_1.2+git102+25ebc270+25ebc27500-r0_all.ipk
3.12/aarch64/vix-obh/enigma2-plugin-extensions-multi-stalkerpro_1.2+git172+c5b05ef0+c5b05efdd0-r0_all.ipk
3.12/aarch64/vix-obh/python3-rarfile_4.1-r0_aarch64.ipk
3.12/arm/atv-pure-egami/enigma2-plugin-extensions-multi-stalkerpro_1.2+git98+f8a2afa0+f8a2afacb3-r0_all.ipk
3.12/arm/vix-obh/enigma2-plugin-extensions-multi-stalkerpro_1.2+git168+7c67a590+7c67a59089-r0_all.ipk
3.12/arm/vix-obh/python3-rarfile_4.1-r0_cortexa15hf-neon-vfpv4.ipk
3.12/mipsel/atv-pure-egami/enigma2-plugin-extensions-multi-stalkerpro_1.2+git101+263845c0+263845c171-r0_all.ipk
3.12/mipsel/vix-obh/enigma2-plugin-extensions-multi-stalkerpro_1.2+git171+66a34f50+66a34f54b4-r0_all.ipk
3.12/mipsel/vix-obh/python3-rarfile_4.1-r0_mips32el.ipk
3.9/arm/openpli/enigma2-plugin-extensions-multi-stalkerpro_1.2+git169+1f4c695-r0_all.ipk
3.9/arm/openpli/python3-fuzzywuzzy_0.18.0-r0_armv7ahf-neon.ipk
3.9/arm/openpli/python3-levenshtein_0.12.0-r0_armv7ahf-neon.ipk
3.9/arm/openpli/python3-rarfile_4.1-r0_armv7ahf-neon.ipk
3.9/mipsel/openpli/enigma2-plugin-extensions-multi-stalkerpro_1.2+git169+1f4c695-r0_all.ipk
3.9/mipsel/openpli/python3-fuzzywuzzy_0.18.0-r0_mips32el.ipk
3.9/mipsel/openpli/python3-levenshtein_0.12.0-r0_mips32el.ipk
3.9/mipsel/openpli/python3-rarfile_4.1-r0_mips32el.ipk
"

echo "> Installing Multi-StalkerPro $LABEL please wait ..."

if [ -f /var/lib/dpkg/status ]; then
    echo "> Multi-StalkerPro has no DreamOS package"
    exit 1
fi

# Python version (x.y)
if command -v python3 >/dev/null 2>&1; then
    PY=$(python3 --version 2>&1 | awk '{print $2}' | cut -d. -f1-2)
else
    PY=$(python --version 2>&1 | awk '{print $2}' | cut -d. -f1-2)
fi
echo "> Python: $PY"

# cpu
ARCHS=""
case "$(uname -m)" in
    aarch64*) DIR="aarch64"; ARCHS="aarch64" ;;
    mips*) DIR="mipsel"; ARCHS="mips32el" ;;
    arm*)
        DIR="arm"
        FEEDS=$(ls /etc/opkg/ 2>/dev/null)
        for a in cortexa15hf-neon-vfpv4 cortexa9hf-neon cortexa7hf-vfp armv7ahf-neon; do
            case "$FEEDS" in
                *"$a"*) ARCHS="$ARCHS $a" ;;
            esac
        done
        # armv7ahf-neon builds run on every ARM box, keep them as last choice
        case "$ARCHS" in *armv7ahf-neon*) ;; *) ARCHS="$ARCHS armv7ahf-neon" ;; esac
        ;;
    *) echo "> CPU $(uname -m) is not supported"; exit 1 ;;
esac
echo "> CPU: $DIR ($ARCHS)"

# image (only 1.1 and 1.2 have different builds per image)
IMGTXT=$(cat /etc/image-version /etc/issue 2>/dev/null | tr 'A-Z' 'a-z')
case "$IMGTXT" in
    *openpli*) IMG="openpli" ;;
    *openvix*|*openbh*|*blackhole*) IMG="vix-obh" ;;
    *) IMG="atv-pure-egami" ;;
esac

# pick the plugin package and the extra packages next to it
PLUGIN=""
EXTRA=""
for line in $FILES; do
    p=$(echo "$line" | cut -d/ -f1)
    d=$(echo "$line" | cut -d/ -f2)
    i=$(echo "$line" | cut -d/ -f3)
    f=$(echo "$line" | cut -d/ -f4)
    [ "$p" = "$PY" ] || continue
    [ "$d" = "$DIR" ] || continue
    [ "$i" = "-" ] || [ "$i" = "$IMG" ] || continue
    ok=""
    case "$f" in
        *_all.ipk) ok=1 ;;
        *)
            for a in $ARCHS; do
                case "$f" in *"_${a}"*) ok=1 ;; esac
            done
            ;;
    esac
    [ -n "$ok" ] || continue
    case "$f" in
        *multi-stalkerpro*) [ -z "$PLUGIN" ] && PLUGIN="$line" ;;
        *) EXTRA="$EXTRA $line" ;;
    esac
done

if [ -z "$PLUGIN" ]; then
    echo "> Multi-StalkerPro $LABEL has no build for this box (python $PY, $DIR, $IMG)"
    exit 1
fi

url_of() {
    p=$(echo "$1" | cut -d/ -f1)
    d=$(echo "$1" | cut -d/ -f2)
    i=$(echo "$1" | cut -d/ -f3)
    f=$(echo "$1" | cut -d/ -f4)
    if [ "$i" = "-" ]; then
        echo "$BASE/v1.2/python$p/$d/$f"
    elif [ "$i" = "openpli" ]; then
        echo "$BASE/v1.2/python$p/openpli/$d/$f"
    else
        echo "$BASE/v1.2/python$p/$d/$i/$f"
    fi
}

get() {
    # $1 = url, $2 = file
    rm -f "$2"
    wget -q --no-check-certificate -O "$2" "$1" >/dev/null 2>&1
    [ -s "$2" ]
}

rm -rf "$TMPD"
mkdir -p "$TMPD" || exit 1

echo "> Installing needed Python packages ..."
opkg update >/dev/null 2>&1
if [ "$PY" != "2.7" ]; then
    for dep in requests six cryptography pycryptodome dateutil pillow sqlite3 rarfile rapidfuzz fuzzywuzzy levenshtein; do
        opkg list-installed | grep "python3-$dep " >/dev/null && continue
        opkg install "python3-$dep" >/dev/null 2>&1
    done
    # rarfile / rapidfuzz from the author when the feed has none
    if ! opkg list-installed | grep "python3-rarfile " >/dev/null; then
        get "$BASE/DEPS/Python/python$PY/python3-rarfile_4.2-r0_all.ipk" "$TMPD/rarfile.ipk" && opkg install "$TMPD/rarfile.ipk" >/dev/null 2>&1
    fi
    if ! opkg list-installed | grep "python3-rapidfuzz " >/dev/null; then
        for a in $ARCHS; do
            get "$BASE/DEPS/Python/python$PY/$DIR/python3-rapidfuzz_3.11.0_${a}.ipk" "$TMPD/rapidfuzz.ipk" && opkg install "$TMPD/rapidfuzz.ipk" >/dev/null 2>&1 && break
        done
    fi
fi
for e in $EXTRA; do
    f=$(echo "$e" | cut -d/ -f4)
    get "$(url_of "$e")" "$TMPD/$f" && opkg install --force-overwrite "$TMPD/$f" >/dev/null 2>&1
done

PF=$(echo "$PLUGIN" | cut -d/ -f4)
echo "> Package: $PF"
if ! get "$(url_of "$PLUGIN")" "$TMPD/$PF"; then
    rm -rf "$TMPD"
    echo "> Download failed, Multi-StalkerPro $LABEL was NOT installed"
    exit 1
fi

# keep the user's settings, remove any other version
[ -f /etc/enigma2/MultiStalkerPro.json ] && cp -f /etc/enigma2/MultiStalkerPro.json "$TMPD/MultiStalkerPro.json"
opkg remove enigma2-plugin-extensions-multi-stalkerpro >/dev/null 2>&1
opkg remove enigma2-plugin-subscription-multi-stalkerpro >/dev/null 2>&1
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/MultiStalkerPro

opkg install --force-reinstall --force-overwrite --force-downgrade "$TMPD/$PF"
[ -f "$TMPD/MultiStalkerPro.json" ] && cp -f "$TMPD/MultiStalkerPro.json" /etc/enigma2/MultiStalkerPro.json
rm -rf "$TMPD"

if ! opkg list-installed | grep "multi-stalkerpro" >/dev/null; then
    echo "> Multi-StalkerPro $LABEL was NOT installed"
    exit 1
fi
sync
echo "> Multi-StalkerPro $LABEL installed successfully"
echo "> Please restart the GUI"
exit 0
