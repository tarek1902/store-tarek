"""A virtual first-party shelf: references the same app records, never duplicates."""
import json,os
BRAND='إضافات سكاي بلو'
def branded(item):return item.get('skyblue_official') is True
def in_category(item,category):return branded(item) if category==BRAND else item['category']==category
def enrich(items,root):
    with open(os.path.join(root,'skyblue-apps.json'),encoding='utf-8') as stream:official=json.load(stream)
    updates={item['id']:item for item in official}
    result=[]
    for item in items:
        if item['id'] in updates:
            item=dict(item);item.update(updates.pop(item['id']))
        result.append(item)
    result.extend(updates.values())
    return result
