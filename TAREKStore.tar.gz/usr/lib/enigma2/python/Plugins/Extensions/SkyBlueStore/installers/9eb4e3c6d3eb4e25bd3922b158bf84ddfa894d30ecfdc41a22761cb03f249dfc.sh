#!/bin/sh
# E2 Piconizer installer (KiddaC) - https://github.com/kiddac/E2_Piconizer
# Downloads the latest master branch from GitHub and copies it to the box.

NAME="E2 Piconizer"
TMPDIR="/tmp/kiddac_install"

download() {
    # $1 = url, $2 = file
    rm -f "$2"
    wget -q -O "$2" "$1" >/dev/null 2>&1
    if [ ! -s "$2" ]; then
        rm -f "$2"
        wget -q --no-check-certificate -O "$2" "$1" >/dev/null 2>&1
    fi
    [ -s "$2" ]
}

copy_files() {
    # $1 = folder that holds usr/ (and maybe etc/)
    find "$1" -name "*.pyc" -o -name "*.pyo" | xargs rm -f 2>/dev/null
    find "$1" -name "__pycache__" -type d | xargs rm -rf 2>/dev/null
    cp -rf "$1/usr" / || return 1
    if [ -d "$1/etc" ]; then
        # keep the user's own settings: only add files that are missing
        ( cd "$1/etc" && find . -type f ) | while read -r f; do
            if [ ! -e "/etc/$f" ]; then
                mkdir -p "$(dirname "/etc/$f")"
                cp -f "$1/etc/$f" "/etc/$f"
            fi
        done
    fi
    return 0
}

install_repo() {
    # $1 = repo, $2 = branch, $3 = sub folder, $4 = file that must exist
    echo "> Downloading $1 ..."
    rm -rf "$TMPDIR"
    mkdir -p "$TMPDIR" || return 1
    if ! download "https://github.com/kiddac/$1/archive/refs/heads/$2.tar.gz" "$TMPDIR/src.tar.gz"; then
        echo "> Download failed ($1)"
        return 1
    fi
    if ! tar -xzf "$TMPDIR/src.tar.gz" -C "$TMPDIR" >/dev/null 2>&1; then
        echo "> Extract failed ($1)"
        return 1
    fi
    ROOT="$TMPDIR/$1-$2"
    [ -n "$3" ] && ROOT="$ROOT/$3"
    if [ ! -f "$ROOT/$4" ]; then
        echo "> Wrong archive, $4 not found ($1)"
        return 1
    fi
    if ! copy_files "$ROOT"; then
        echo "> Copy failed ($1)"
        return 1
    fi
    if [ ! -f "/$4" ]; then
        echo "> Install check failed ($1)"
        return 1
    fi
    return 0
}

echo "> Installing $NAME please wait ..."

if ! install_repo "E2_Piconizer" "master" "E2Piconizer" "usr/lib/enigma2/python/Plugins/Extensions/E2Piconizer/plugin.py"; then
    rm -rf "$TMPDIR"
    echo "> $NAME was NOT installed"
    exit 1
fi
rm -rf "$TMPDIR"
sync
echo "> $NAME installed successfully"
echo "> Please restart the GUI"
exit 0
