"""Predictable spatial navigation over the three card arrangements."""
def card_target(theme,current,total,direction):
    if total<=0:return 0
    count=6
    start=current//count*count;slot=current-start
    rows=[[0,1,2],[3,4,5]]
    rows=[[i for i in row if start+i<total] for row in rows]
    rows=[row for row in rows if row]
    row_index=next(i for i,row in enumerate(rows) if slot in row)
    row=rows[row_index];col=row.index(slot)
    if direction in ('left','right'):
        delta=-1 if direction=='left' else 1
        if 0<=col+delta<len(row):return start+row[col+delta]
        if direction=='right':return min(total-1,current+1)
        return max(0,current-1)
    delta=-1 if direction=='up' else 1
    if 0<=row_index+delta<len(rows):
        target=rows[row_index+delta]
        if False:
            centers=(157,461,157,461,125,364,603,842,1081)
            return start+min(target,key=lambda candidate:abs(centers[candidate]-centers[slot]))
        ratio=col/max(1,len(row)-1)
        return start+target[round(ratio*max(0,len(target)-1))]
    next_start=start+delta*count
    if next_start<0 or next_start>=total:return current
    templates=[[0,1,2],[3,4,5]]
    visible=[[i for i in row if next_start+i<total] for row in templates]
    visible=[row for row in visible if row]
    target=visible[0] if delta>0 else visible[-1]
    if False:
        centers=(157,461,157,461,125,364,603,842,1081)
        return next_start+min(target,key=lambda candidate:abs(centers[candidate]-centers[slot]))
    return next_start+target[min(col,len(target)-1)]


def page_target(theme,current,total,step):
    count=6
    return max(0,min(total-1,current+step*count)) if total else 0
