"""Explicitly selected, checksum-pinned upstream installers; no shell interpolation."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time
from .core import installed_packages, secure_url, urlopen


def defer_gui_restart(text):
    """Keep installer file/package work, but defer service restarts until UI exit."""
    boundary=r'(^[ \t]*|[;&|][ \t]*|\bthen[ \t]+|\bdo[ \t]+)'
    command=r'(?:(?:/sbin/|/bin/)?init\s+[0346]\b|(?:/sbin/|/bin/)?killall\s+(?:-\w+\s+)*enigma2\b|(?:/sbin/|/bin/)?(?:reboot|poweroff|halt)\b)'
    return re.sub(boundary+command,lambda m:m[1]+"echo '[Sky Blue] GUI restart deferred until installation finishes'",text,flags=re.M)


def check_compatibility(item,info):
    if item.get('target_images') and info['image'] not in item['target_images']:
        raise ValueError('المثبّت مخصص لصورة أخرى: '+', '.join(item['target_images']))
    if item.get('target_python_major') and int(info['python'].split('.')[0]) not in item['target_python_major']:
        raise ValueError('المثبّت مخصص لإصدار Python مختلف')


def prepare_script(item,info,root):
    check_compatibility(item,info)
    spec=item.get('script_install')
    if not isinstance(spec,dict):raise ValueError('لا يوجد مثبّت متاح لهذه البطاقة')
    if spec.get('url'):
        url=secure_url(spec['url'])
        with urlopen(url,timeout=30) as response:
            secure_url(response.geturl());raw=response.read(512*1024+1)
    else:
        name=spec.get('bundle','')
        if not re.fullmatch(r'[a-f0-9]{64}\.sh',name):raise ValueError('اسم ملف المثبّت غير صالح')
        parent=(Path(root)/'installers').resolve();path=(parent/name).resolve()
        if path.parent!=parent:raise ValueError('مسار المثبّت غير صالح')
        raw=path.read_bytes()
    if not raw or len(raw)>512*1024 or hashlib.sha256(raw).hexdigest()!=spec.get('sha256'):
        raise ValueError('تغير ملف المثبّت من المصدر؛ يلزم تحديث فهرس المصدر قبل تشغيله')
    text=raw.decode('utf-8-sig').replace('\r\n','\n')
    text=text.replace('"--no-check-certificate"','').replace("'--no-check-certificate'",'').replace('--no-check-certificate','')
    text=re.sub(r'(?m)(\bcurl\s+[^\n]*?)\s--insecure\b',r'\1',text)
    text=re.sub(r'(?m)(\bcurl\s+[^\n]*?)\s-k\b',r'\1',text)
    text=defer_gui_restart(text)
    reason=blocked_reason(text)
    if reason:raise ValueError(reason)
    task=Path(tempfile.mkdtemp(prefix='skyblue-script-',dir='/tmp'))
    path=task/'install.sh';path.write_text(text,encoding='utf-8');path.chmod(0o600)
    shell=shutil.which('bash') if text.startswith('#!/bin/bash') else '/bin/sh'
    if not shell:raise ValueError('هذا المثبّت يحتاج bash غير الموجود في الصورة')
    result=subprocess.run([shell,'-n',str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15)
    if result.returncode:raise ValueError('صيغة سكربت المصدر غير صالحة: '+result.stdout.decode('utf-8','replace')[-700:])
    return {'task':str(task),'path':str(path),'shell':shell,'name':item['name'],'source':spec.get('url') or 'ملف السكربت المرفق','id':item['id']}


def blocked_reason(text):
    active='\n'.join(line for line in text.splitlines() if not line.lstrip().startswith('#'))
    if re.search(r'\b(?:mkfs\S*|flash_erase\S*|nandwrite|ubiformat)\b|\bdd\s+[^\n]*\bof=/dev/',active):
        return 'هذا سكربت تفليش أو تهيئة، ولا يعمل من مثبت الإضافات'
    if re.search(r'(?m)(?:^\s*|[;&|]\s*|\bthen\s+)(?:exec\s+)?(?:/sbin/|/bin/)?(?:reboot|poweroff|halt)\b|\binit\s+[046]\b|\bkillall\s+(?:-\w+\s+)?enigma2\b',active):
        return 'المثبّت يعيد تشغيل الجهاز تلقائيًا؛ يلزم تجهيز نسخة لا تقطع الواجهة'
    if re.search(r'\brm\s+[^\n;]*\s/(?:\s|$)|\brm\s+[^\n;]*/etc/enigma2(?:/\*|\s|$)',active):
        return 'المثبّت يتضمن حذفًا عامًا لإعدادات الجهاز؛ يحتاج تعديلًا قبل إتاحته'
    if re.search(r'\b(?:wget|curl)\b[^\n]*https?://',active):
        # Never turn a source's insecure HTTP download into root execution.
        if re.search(r'\b(?:wget|curl)\b[^\n]*\bhttp://',active):return 'المثبّت ينزل عبر HTTP؛ يحتاج رابط HTTPS من المصدر'
    return None


def changed_targets():
    result={}
    for folder,names in [('/usr/lib/enigma2/python/Plugins/Extensions',('plugin.py','__init__.py')),('/usr/share/enigma2',('skin.xml',))]:
        root=Path(folder)
        if not root.is_dir():continue
        for directory in root.iterdir():
            if not directory.is_dir():continue
            for name in names:
                target=directory/name
                if target.is_file():
                    stat=target.stat();result[str(target)]=(stat.st_mtime_ns,stat.st_size)
    return result


def execute_script(job):
    task=Path(job['task']);log=task/'install.log'
    before=installed_packages();targets=changed_targets()
    lock=Path('/tmp/skyblue-store-install.lock')
    try:fd=os.open(str(lock),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    except FileExistsError:raise ValueError('يوجد تثبيت آخر قيد التشغيل')
    process=None
    try:
        os.close(fd)
        with log.open('wb') as output:
            output.write(('Source: '+job['source']+'\n').encode());output.flush()
            env=dict(os.environ);env.pop('LD_PRELOAD',None)
            process=subprocess.Popen([job['shell'],job['path']],cwd=job['task'],stdout=output,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,env=env,start_new_session=True)
            try:code=process.wait(timeout=900)
            except subprocess.TimeoutExpired:
                import signal
                os.killpg(process.pid,signal.SIGTERM)
                try:process.wait(timeout=10)
                except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
                raise RuntimeError('انتهت مهلة المثبّت. السجل: '+str(log))
        after=installed_packages();after_targets=changed_targets()
        packages={k:v for k,v in after.items() if before.get(k)!=v}
        written=[p for p,v in after_targets.items() if targets.get(p)!=v]
        result={'returncode':code,'packages':packages,'changed_files':written,'confirmed':code==0 and bool(packages or written),'log':str(log),'name':job['name']}
        if code:raise RuntimeError('فشل المثبّت برمز '+str(code)+'؛ السجل: '+str(log))
        if result['confirmed']:
            receipt=Path('/etc/enigma2/skyblue-store-script-installed.json')
            try:
                rows=json.loads(receipt.read_text(encoding='utf-8')) if receipt.exists() else {}
                rows[job['id']]={'confirmed':True,'version':next(iter(packages.values()),'ملفات المصدر'),'installed_at':int(time.time())}
                temp=receipt.with_suffix('.tmp');temp.write_text(json.dumps(rows),encoding='utf-8');temp.chmod(0o600);os.replace(str(temp),str(receipt))
            except (OSError,ValueError,TypeError):pass
        (task/'result.json').write_text(json.dumps(result),encoding='utf-8')
        return result
    finally:
        lock.unlink(missing_ok=True)
