import os
import re
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from twisted.internet import threads
from enigma import getDesktop, eTimer, ePoint
from .core import device_info, read_catalog, compatible, install, installed_packages, installed_version, newer_version
from .layout import fullscreen
from .resolver import resolve_reference
from .sections import subgroup, availability
from .brand import BRAND, branded, in_category
from .script_metadata import entry_prefix, source_details, group_icon, display_metadata
from .script_install import prepare_script, execute_script, check_compatibility

BASE = os.path.dirname(__file__)
CATEGORIES = ['الكل', 'البلجنات', 'السكنات', 'القنوات', 'الأيقونات', 'الوسائط', 'الأدوات', 'النظام', 'النسخ والاستعادة', 'مشغلات الخدمة', 'قيد التجهيز']


class SkyBlueStore(Screen):
    skin = '''<screen name="SkyBlueStore" position="center,center" size="1200,660" title="Sky Blue Store" backgroundColor="#0b1018">
    <eLabel position="0,0" size="1200,4" backgroundColor="#8be9ef" />
    <eLabel position="36,25" size="500,48" text="SKY BLUE / STORE" font="Regular;34" foregroundColor="#8be9ef" backgroundColor="#0b1018" />
    <widget name="device" position="610,34" size="550,38" font="Regular;20" halign="right" foregroundColor="#a7bacb" backgroundColor="#0b1018" />
    <eLabel position="36,92" size="1128,1" backgroundColor="#2a3544" />
    <widget name="category" position="36,106" size="1128,40" font="Regular;25" halign="right" foregroundColor="#eacb9a" backgroundColor="#0b1018" />
    <eLabel position="36,158" size="452,392" backgroundColor="#142332" zPosition="-1" />
    <widget name="installed_badge" position="62,168" size="42,42" alphatest="blend" scale="1" zPosition="3" />
    <widget name="list" position="516,158" size="648,392" itemHeight="56" font="Regular;25" backgroundColor="#101c2a" foregroundColor="#edf4f7" selectionBackgroundColor="#23556b" selectionForegroundColor="#ffffff" scrollbarMode="showOnDemand" />
    <widget name="state" position="122,174" size="338,32" font="Regular;21" foregroundColor="#83e5b4" backgroundColor="#142332" halign="right" />
    <widget name="app_icon" position="58,221" size="76,76" alphatest="blend" scale="1" />
    <widget name="name" position="148,224" size="312,75" font="Regular;26" foregroundColor="#e9f3f8" backgroundColor="#142332" />
    <widget name="author" position="58,312" size="402,36" font="Regular;20" foregroundColor="#c5d6e4" backgroundColor="#142332" />
    <widget name="release" position="58,352" size="402,48" font="Regular;19" foregroundColor="#eacb9a" backgroundColor="#142332" />
    <widget name="description" position="58,409" size="402,58" font="Regular;19" foregroundColor="#b4c6d6" backgroundColor="#142332" />
    <widget name="status" position="58,478" size="402,62" font="Regular;18" foregroundColor="#8be9ef" backgroundColor="#142332" />
    <eLabel position="36,570" size="1128,2" backgroundColor="#2a3544" />
    <eLabel position="36,596" size="220,36" text="EXIT: خروج" font="Regular;23" foregroundColor="#eb8c9c" backgroundColor="#0b1018" />
    <eLabel position="290,596" size="250,36" text="الأخضر: تثبيت" font="Regular;23" foregroundColor="#8ad8b7" backgroundColor="#0b1018" />
    <eLabel position="570,596" size="280,36" text="الأصفر: دليل الأقسام" font="Regular;23" foregroundColor="#eacb9a" backgroundColor="#0b1018" />
    <eLabel position="900,596" size="260,36" text="الأزرق: فحص الإصدار" font="Regular;23" foregroundColor="#91b9f2" backgroundColor="#0b1018" />
    </screen>'''

    def __init__(self, session, initial_category=None, subcategory=None):
        desktop = getDesktop(0).size()
        self.skin = fullscreen(type(self).skin, desktop.width(), desktop.height())
        Screen.__init__(self, session)
        self.info = device_info()
        self.store_items = []
        self.package_state = {}
        self.update_flags = {}
        self['installed_badge'] = Pixmap()
        self['app_icon'] = Pixmap()
        self.category_index = 0
        self.initial_category = initial_category
        self.subcategory_filter = subcategory
        self.categories = list(CATEGORIES)
        self.busy = False
        self.alive = True
        for key in ('device', 'category', 'name', 'description', 'status', 'state', 'author', 'release'):
            self[key] = Label('')
        self['list'] = MenuList([])
        self['list'].onSelectionChanged.append(self.selected)
        self['device'].setText('{image} {version} / {arch}'.format(**self.info))
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions', 'DirectionActions', 'MenuActions'], {
            'cancel': self.leave, 'ok': self.confirm, 'green': self.confirm,
            'blue': self.check_selected_update, 'left': lambda: self.category(-1), 'right': lambda: self.category(1),
            'yellow': self.choose_category, 'menu': self.show_source_details,
            'up': self['list'].up, 'down': self['list'].down}, -1)
        self.onClose.append(self._on_close)
        self.onFirstExecBegin.append(self.load)

    def _on_close(self):
        if not getattr(self, 'alive', False):
            return
        self.alive = False
        callbacks = self['list'].onSelectionChanged
        if self.selected in callbacks:
            callbacks.remove(self.selected)

    def leave(self):
        if not getattr(self, 'alive', False):
            return
        if self.busy:
            self.session.open(MessageBox, 'انتظر اكتمال العملية الحالية.', MessageBox.TYPE_INFO)
        else:
            self._on_close()
            self.close()

    def load(self):
        if not getattr(self, 'alive', False) or self.busy:
            return
        self.busy = True
        self['status'].setText('جارٍ تحميل المكتبة…')
        source = os.path.join(BASE, 'catalog.json')
        config = '/etc/enigma2/skyblue-store-url'
        if os.path.isfile(config):
            with open(config) as stream:
                source = stream.read().strip()
            if not source.startswith('https://'):
                self.failed(ValueError('عنوان المكتبة يجب أن يستخدم HTTPS'))
                return
        # The bundled catalog is tiny and needs no reactor/thread round trip.
        # Keep network requests off the GUI thread.
        if source.startswith('https://'):
            threads.deferToThread(read_catalog, source).addCallbacks(self.loaded, self.failed)
        else:
            try:
                self.loaded(read_catalog(source))
            except Exception as error:
                self.failed(error)

    def loaded(self, items):
        if not getattr(self, 'alive', False):
            return
        self.busy = False
        if self.alive:
            self.store_items = items
            available = set(item['category'] for item in items)
            if any(branded(item) for item in items):available.add(BRAND)
            self.categories = [c for c in CATEGORIES if c == 'الكل' or c in available] + sorted(available - set(CATEGORIES))
            self.category_index = min(self.category_index, len(self.categories) - 1)
            if self.initial_category in self.categories:
                self.category_index = self.categories.index(self.initial_category)
                self.initial_category = None
            self.render()

    def failed(self, error):
        if not getattr(self, 'alive', False):
            return
        self.busy = False
        if self.alive:
            self['status'].setText(str(getattr(error, 'value', error)))

    def category(self, step):
        if getattr(self, 'alive', False) and not self.busy:
            self.subcategory_filter = None
            self.category_index = (self.category_index + step) % len(self.categories)
            self.render()

    def render(self):
        if not getattr(self, 'alive', False):
            return
        category = self.categories[self.category_index]
        self.package_state = installed_packages()
        rows = [(entry_prefix(item,installed_version(item,self.package_state),self.update_flags.get(item['id'])) + item['name'], item) for item in self.store_items if (category == 'الكل' or in_category(item,category)) and (not self.subcategory_filter or subgroup(item) == self.subcategory_filter)]
        self['category'].setText('‹  ' + category + (' / '+self.subcategory_filter if self.subcategory_filter else '') + '  ›  ·  ' + str(len(rows)) + ' عنصر')
        self['list'].setList(rows)
        self.selected()

    def choose_category(self):
        if not getattr(self, 'alive', False) or self.busy:
            return
        choices = [(c + '  (' + str(sum(1 for item in self.store_items if c == 'الكل' or item['category'] == c)) + ')', c) for c in self.categories]
        self.session.openWithCallback(self.category_chosen, ChoiceBox, title='أقسام Sky Blue Store', list=choices)

    def show_source_details(self):
        if not getattr(self,'alive',False) or self.busy:return
        row=self['list'].getCurrent()
        if row:self.session.open(StoreSourceDetails,row[1])

    def category_chosen(self, choice):
        if getattr(self, 'alive', False) and choice:
            self.category_index = self.categories.index(choice[1])
            self.subcategory_filter = None
            self.render()

    def selected(self):
        if not getattr(self, 'alive', False):
            return
        row = self['list'].getCurrent()
        item = row[1] if row else None
        self['name'].setText(item['name'] if item else 'المكتبة جاهزة للإضافات')
        self['description'].setText((subgroup(item)+'\n'+item['description']) if item else 'لا توجد إضافات في هذا القسم حتى الآن.')
        version = installed_version(item,self.package_state) if item else None
        author,release=display_metadata(item,version) if item else ('','')
        self['author'].setText(author);self['release'].setText(release)
        if self['app_icon'].instance is not None:
            icon_path=os.path.join(BASE,'assets','apps',item['id']+'.png') if item else ''
            if not os.path.isfile(icon_path):icon_path=os.path.join(BASE,'assets',group_icon(subgroup(item),item['category'])+'.png') if item else os.path.join(BASE,'assets','plugins.png')
            self['app_icon'].instance.setPixmapFromFile(icon_path)
        update=self.update_flags.get(item['id']) if item else None
        self['state'].setText('تحديث متاح' if update else 'مثبّتة على جهازك' if version is not None else 'غير متاحة حاليًا' if item and item.get('pending_review') else 'جاهزة للتثبيت' if item else '')
        badge=self['installed_badge']
        if version is not None and badge.instance is not None:
            badge.instance.setPixmapFromFile(os.path.join(BASE,'assets','installed.png'))
            badge.show()
        else:
            badge.hide()
        if item and item.get('pending_review'):
            self['status'].setText(('رابط المصدر يحتاج فحصًا' if item.get('review_status')=='source-unavailable' else 'المثبّت يحتاج مراجعة')+'\nMENU: المصدر والتفاصيل')
            return
        if item and item.get('script_install'):
            self['status'].setText(('الإصدار المثبّت: '+version if version else 'OK / الأخضر: تنزيل وتثبيت')+'\nMENU: تفاصيل الإضافة')
            return
        if version is not None:
            available=self.update_flags.get(item['id'])
            self['status'].setText(('تحديث متاح: '+available+'\nالمثبت: '+version) if available else 'مثبّت على جهازك · الإصدار: '+version+'\nالأزرق: فحص تحديث المصدر')
            return
        if item and item.get('reference_only'):
            self['status'].setText('OK / الأخضر: تنزيل وتثبيت\nMENU: تفاصيل الإضافة')
            return
        self['status'].setText(('الإصدار: ' + item['version'] + '\n' +
            ('متوافق مع جهازك' if compatible(item, self.info) else 'غير متوافق مع هذا الجهاز'))
            if item else 'Sky Blue Store / 0.7.0')

    def check_selected_update(self):
        row=self['list'].getCurrent()
        if self.busy or not row:
            return
        original=row[1]
        if original.get('script_install'):
            self['status'].setText('هذا المصدر يستخدم مثبّتًا بالأوامر.\nالأخضر: جلب المثبّت وإعادة تشغيله بعد التأكيد.')
            return
        if original.get('pending_review'):
            self['status'].setText('هذه الإضافة قيد المراجعة؛ لا يمكن فحص تحديثها أو تثبيتها حاليًا.')
            return
        self.busy=True
        self['status'].setText('جارٍ فحص إصدار المصدر…')
        def check():
            resolved=resolve_reference(original,self.info) if original.get('reference_only') else original
            version=installed_version(resolved,installed_packages())
            return resolved,version,bool(version and newer_version(resolved['version'],version))
        def done(result):
            if not getattr(self,'alive',False):return
            self.busy=False
            resolved,version,newer=result
            original['package_id']=resolved['id']
            self.update_flags[original['id']]=resolved['version'] if newer else None
            index=self['list'].getSelectionIndex()
            self.render()
            self['list'].moveToIndex(index)
            if not newer:self['status'].setText('لا يوجد إصدار أحدث في هذا المصدر.' if version else 'إصدار المصدر: '+resolved['version']+' · غير مثبتة')
        threads.deferToThread(check).addCallbacks(done,self.failed)

    def confirm(self):
        if not getattr(self, 'alive', False):
            return
        row = self['list'].getCurrent()
        if self.busy or not row:
            return
        item = row[1]
        if item.get('pending_review'):
            self.session.open(StoreSourceDetails,item)
            return
        if item.get('script_install'):
            try:check_compatibility(item,self.info)
            except Exception as error:
                self.failed(error);return
            self.session.openWithCallback(lambda answer:self.session.openWithCallback(self.script_closed,StoreScriptInstall,item,self.info) if answer and getattr(self,'alive',False) else None,
                MessageBox,'تثبيت '+item['name']+'؟\nسيتم تنزيل الإضافة وتثبيت ملفاتها ومتطلباتها. لا تغلق الجهاز أثناء التثبيت.',MessageBox.TYPE_YESNO,default=False)
            return
        if item.get('reference_only'):
            self.busy = True
            self['status'].setText('جارٍ قراءة المصدر وجلب بيانات الحزمة…')
            threads.deferToThread(resolve_reference,item,self.info).addCallbacks(self.reference_resolved,self.failed)
            return
        if not compatible(item, self.info):
            self.session.open(MessageBox, 'الحزمة غير متوافقة.', MessageBox.TYPE_ERROR)
            return
        self.session.openWithCallback(lambda answer: self.start_install(item) if answer else None,
            MessageBox, 'تثبيت ' + item['name'] + '؟', MessageBox.TYPE_YESNO)

    def reference_resolved(self,item):
        if not getattr(self,'alive',False):
            return
        self.busy=False
        row=self['list'].getCurrent()
        if row:
            row[1]['package_id']=item['id']
        self['status'].setText('تم جلب بيانات الإصدار: '+item['version'])
        self.session.openWithCallback(lambda answer: self.start_install(item) if answer else None,
            MessageBox,'تثبيت '+item['name']+'\nالإصدار: '+item['version']+'\nحزمة خارجية؛ فُحصت بياناتها الأولية ولم يُختبر تشغيلها على هذا الجهاز. هل تريد المتابعة؟',MessageBox.TYPE_YESNO,default=False)

    def script_closed(self,result=None):
        if not getattr(self,'alive',False):return
        index=self['list'].getSelectionIndex();self.render();self['list'].moveToIndex(index)

    def start_install(self, item):
        if not getattr(self, 'alive', False) or self.busy:
            return
        self.busy = True
        self['status'].setText('جارٍ التنزيل والتحقق والتثبيت…')
        threads.deferToThread(install, item, self.info).addCallbacks(self.installed, self.failed)

    def installed(self, message):
        if not getattr(self, 'alive', False):
            return
        self.busy = False
        if self.alive:
            index=self['list'].getSelectionIndex()
            self.render()
            self['list'].moveToIndex(index)
            self['status'].setText(message)
            self.session.open(StoreSuccess)


class StoreScriptInstall(Screen):
    skin='''<screen position="0,0" size="1200,660" flags="wfNoBorder" backgroundColor="#0b1018">
    <widget name="heading" position="36,28" size="1128,48" font="Regular;30" foregroundColor="#8be9ef" transparent="1"/>
    <widget name="log" position="36,102" size="1128,430" font="Regular;19" foregroundColor="#edf4f7" backgroundColor="#142332"/>
    <widget name="result" position="36,555" size="1128,75" font="Regular;23" foregroundColor="#8be9ef" transparent="1"/>
    </screen>'''

    def __init__(self,session,item,info):
        size=getDesktop(0).size();self.skin=fullscreen(type(self).skin,size.width(),size.height())
        Screen.__init__(self,session)
        self['heading']=Label('تثبيت: '+item['name'])
        self['log']=ScrollLabel('جارٍ جلب المثبّت وفحصه…')
        self['result']=Label('انتظر اكتمال التثبيت. لا تفصل الجهاز.')
        self.running=True;self.alive=True;self.job=None
        self.timer=eTimer();self.timer.callback.append(self.refresh_log)
        self['actions']=ActionMap(['OkCancelActions','DirectionActions'],{'ok':self.leave,'cancel':self.leave,'up':self['log'].pageUp,'down':self['log'].pageDown},-1)
        self.onClose.append(self.cleanup)
        self.onFirstExecBegin.append(lambda:threads.deferToThread(prepare_script,item,info,BASE).addCallbacks(self.prepared,self.failed))

    def prepared(self,job):
        if not self.alive:return
        self.job=job;self.timer.start(400,False)
        threads.deferToThread(execute_script,job).addCallbacks(self.finished,self.failed)

    def refresh_log(self):
        if not self.alive or not self.job:return
        try:
            path=os.path.join(self.job['task'],'install.log')
            with open(path,'rb') as stream:
                stream.seek(max(0,os.path.getsize(path)-24000));text=stream.read().decode('utf-8','replace')
            text=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',text)
            self['log'].setText(text);self['log'].lastPage()
        except OSError:pass

    def finished(self,result):
        if not self.alive:return
        self.running=False;self.timer.stop();self.refresh_log()
        message='تم التثبيت وتأكد تغير ملفات الإضافة أو إصدار الحزمة.' if result['confirmed'] else 'انتهى أمر المثبّت دون خطأ؛ لم يتأكد تغير حزمة أو ملف إضافة.'
        self['result'].setText(message+'\nOK / EXIT: رجوع. أعد تشغيل الواجهة لاحقًا إذا طلب المصدر ذلك.')

    def failed(self,error):
        if not self.alive:return
        self.running=False;self.timer.stop();self.refresh_log()
        self['result'].setText(str(getattr(error,'value',error))+'\nOK / EXIT: رجوع')

    def leave(self):
        if not self.running:self.close()

    def cleanup(self):
        self.alive=False;self.timer.stop()
        if self.refresh_log in self.timer.callback:self.timer.callback.remove(self.refresh_log)


class StoreSourceDetails(Screen):
    """Scrollable source information, independent of the receiver MessageBox skin."""
    skin='''<screen position="0,0" size="1200,660" flags="wfNoBorder" backgroundColor="#0b1018">
    <eLabel position="36,28" size="1128,48" text="SKY BLUE / SOURCE DETAILS" font="Regular;30" foregroundColor="#8be9ef" transparent="1"/>
    <eLabel position="36,94" size="1128,2" backgroundColor="#2a3544"/>
    <widget name="body" position="48,118" size="1104,438" font="Regular;23" foregroundColor="#edf4f7" backgroundColor="#142332"/>
    <eLabel position="36,580" size="1128,2" backgroundColor="#2a3544"/>
    <eLabel position="36,601" size="1128,35" text="أعلى / أسفل: قراءة التفاصيل  |  OK / EXIT: رجوع" font="Regular;22" foregroundColor="#8be9ef" transparent="1"/>
    </screen>'''

    def __init__(self,session,item):
        size=getDesktop(0).size()
        self.skin=fullscreen(type(self).skin,size.width(),size.height())
        Screen.__init__(self,session)
        self['body']=ScrollLabel(source_details(item))
        self['actions']=ActionMap(['OkCancelActions','DirectionActions','MenuActions'],{
            'ok':self.close,'cancel':self.close,'menu':self.close,
            'up':self['body'].pageUp,'down':self['body'].pageDown,
            'left':self['body'].pageUp,'right':self['body'].pageDown},-1)


class StoreSuccess(Screen):
    skin = '''<screen position="center,center" size="720,330" flags="wfNoBorder" backgroundColor="#142332">
    <ePixmap position="312,28" size="96,96" pixmap="%s/assets/installed.png" alphatest="blend" zPosition="1" />
    <eLabel position="30,150" size="660,54" text="تم التثبيت بنجاح" font="Regular;34" halign="center" foregroundColor="#a4f4cf" backgroundColor="#142332" />
    <eLabel position="30,225" size="660,50" text="OK: العودة إلى المتجر" font="Regular;24" halign="center" foregroundColor="#c6d9e5" backgroundColor="#142332" />
    </screen>''' % BASE

    def __init__(self,session):
        Screen.__init__(self,session)
        self['actions']=ActionMap(['OkCancelActions'],{'ok':self.close,'cancel':self.close},-1)


HOME_SECTIONS = [
    ('البلجنات', 'plugins', 'إضافات الترجمة والصوت والوظائف المساعدة'),
    ('السكنات', 'skins', 'واجهات وصور إقلاع ومؤشرات انتظار'),
    ('القنوات', 'channels', 'قوائم القنوات وتنظيم الباقات'),
    ('الأيقونات', 'picons', 'شعارات القنوات ومكتبات Picons'),
    ('الوسائط', 'media', 'أدوات المشاهدة وتشغيل الوسائط'),
    ('الأدوات', 'tools', 'أدوات مساعدة لجهازك'),
    ('النظام', 'system', 'الصور والمستودعات وإدارة النظام'),
    ('النسخ والاستعادة', 'backup', 'مراجع أدوات النسخ الاحتياطي والاستعادة'),
    ('مشغلات الخدمة', 'service', 'OSCam · السوفتكام وأدوات التشفير')]

try:
    _published_categories = {entry['category'] for entry in read_catalog(os.path.join(BASE,'catalog.json'))}
    HOME_SECTIONS = [section for section in HOME_SECTIONS if section[0] in _published_categories and section[0]!='قيد التجهيز']
except Exception:
    pass


def home_skin():
    parts = ['<screen name="SkyBlueStoreHome" position="center,center" size="1200,660" title="Sky Blue Store" backgroundColor="#0a111b">',
             '<ePixmap position="0,0" size="1200,660" pixmap="%s/assets/home.png" zPosition="-10" />' % BASE,
             '<eLabel position="40,25" size="580,44" text="SKY BLUE / STORE" font="Regular;33" foregroundColor="#a5e9ed" backgroundColor="#0a111b" transparent="1" />',
             '<widget name="hardware" position="650,31" size="510,36" font="Regular;20" halign="right" foregroundColor="#acbece" transparent="1" />',
             '<widget name="hero_icon" position="170,173" size="96,96" alphatest="blend" />',
             '<widget name="focus_ring" position="932,153" size="224,126" pixmap="%s/assets/focus.png" alphatest="blend" />' % BASE,
             '<widget name="hero_name" position="52,298" size="332,52" font="Regular;32" halign="center" foregroundColor="#edf6f9" transparent="1" />',
             '<widget name="hero_description" position="57,363" size="322,90" font="Regular;23" halign="center" foregroundColor="#adc4d6" transparent="1" />',
             '<widget name="hero_count" position="56,480" size="324,45" font="Regular;24" halign="center" foregroundColor="#efcf94" transparent="1" />',
             '<eLabel position="452,111" size="700,32" text="اختر قسمك" font="Regular;22" halign="right" foregroundColor="#adc4d6" transparent="1" />',
             '<eLabel position="40,612" size="220,32" text="EXIT: خروج" font="Regular;22" foregroundColor="#ed91a0" transparent="1" />',
             '<eLabel position="305,612" size="310,32" text="الأزرق: جميع الإضافات" font="Regular;22" foregroundColor="#8dbff3" transparent="1" />',
             '<eLabel position="800,612" size="355,32" text="الأسهم: تنقل  |  OK: فتح القسم" font="Regular;22" halign="right" foregroundColor="#b5cedb" transparent="1" />']
    for index, (name, icon, description) in enumerate(HOME_SECTIONS):
        row, col = divmod(index, 3)
        x, y = 932 - col * 240, 153 + row * 138
        parts += [
            '<widget name="tile%d" position="%d,%d" size="224,126" alphatest="blend" />' % (index, x, y),
            '<ePixmap position="%d,%d" size="64,64" pixmap="%s/assets/%s.png" alphatest="blend" scale="1" />' % (x+80,y+10,BASE,icon),
            '<widget name="caption%d" position="%d,%d" size="206,38" font="Regular;23" halign="center" foregroundColor="#deebf2" transparent="1" />' % (index,x+9,y+81)]
    # Static skin pixmaps default above widgets on some image versions.
    # Assign every layer explicitly so the background cannot hide the focus.
    import xml.etree.ElementTree as ET
    skin = ET.fromstring(''.join(parts) + '</screen>')
    for element in skin:
        if element.get('zPosition') == '-10':
            continue
        name = element.get('name', '')
        if name == 'focus_ring':
            element.set('zPosition','3')
        elif name.startswith('tile'):
            element.set('zPosition', '0')
        elif element.tag == 'ePixmap' or name == 'hero_icon':
            element.set('zPosition', '1')
        else:
            element.set('zPosition', '2')
    return ET.tostring(skin, encoding='unicode')


class SkyBlueStoreHome(Screen):
    skin = home_skin()

    def __init__(self, session):
        desktop = getDesktop(0).size()
        self.skin = fullscreen(type(self).skin, desktop.width(), desktop.height())
        Screen.__init__(self, session)
        self.ui_scale = (desktop.width()/1200.0,desktop.height()/660.0)
        self.home_alive = True
        self.motion_timer = eTimer()
        self.motion_timer.callback.append(self.motion_step)
        self.motion_frame = 0
        self.motion_start = None
        self.motion_target = None
        self.focus_index = 0
        self.section_counts = {}
        self.home_catalog = []
        info = device_info()
        self['hardware'] = Label('{image} {version} / {arch}'.format(**info))
        for name in ('hero_name','hero_description','hero_count'):
            self[name] = Label('')
        self['hero_icon'] = Pixmap()
        self['focus_ring'] = Pixmap()
        for index, (name, icon, description) in enumerate(HOME_SECTIONS):
            self['tile%d' % index] = Pixmap()
            self['caption%d' % index] = Label('OSCam / السوفتكام' if name=='مشغلات الخدمة' else name)
        self['actions'] = ActionMap(['OkCancelActions','DirectionActions','ColorActions'], {
            'cancel': self.close, 'ok': self.open_section,
            'right': lambda: self.move_focus(0,-1), 'left': lambda: self.move_focus(0,1),
            'up': lambda: self.move_focus(-1,0), 'down': lambda: self.move_focus(1,0),
            'blue': lambda: self.open_section('الكل')}, -1)
        self.onLayoutFinish.append(self.ready)
        self.onClose.append(self.stop_motion)
        self.onHide.append(self.pause_motion)

    def pause_motion(self):
        self.motion_timer.stop()
        if self.motion_target and self['focus_ring'].instance is not None:
            self['focus_ring'].instance.move(ePoint(*self.motion_target))

    def stop_motion(self):
        self.home_alive = False
        self.motion_timer.stop()
        if self.motion_step in self.motion_timer.callback:
            self.motion_timer.callback.remove(self.motion_step)

    def motion_step(self):
        if not getattr(self,'home_alive',False):
            return
        self.motion_frame += 1
        t = min(1.0,self.motion_frame/7.0)
        ease = 1.0-(1.0-t)**3
        x,y = self.motion_start
        tx,ty = self.motion_target
        self['focus_ring'].instance.move(ePoint(round(x+(tx-x)*ease),round(y+(ty-y)*ease)))
        if t >= 1:
            self.motion_timer.stop()

    def ready(self):
        try:
            self.home_catalog = read_catalog(os.path.join(BASE,'catalog.json'))
            for entry in self.home_catalog:
                category = entry['category']
                self.section_counts[category] = self.section_counts.get(category,0) + 1
        except Exception:
            pass
        self.paint_focus()

    def move_focus(self, dy, dx):
        step=dy*3+dx
        self.focus_index = (self.focus_index+step)%len(HOME_SECTIONS)
        self.paint_focus()

    def paint_focus(self):
        self.motion_timer.stop()
        for index in range(len(HOME_SECTIONS)):
            instance = self['tile%d' % index].instance
            if instance is not None:
                instance.setPixmapFromFile(os.path.join(BASE,'assets','tile-active.png' if index == self.focus_index else 'tile.png'))
        name, icon, description = HOME_SECTIONS[self.focus_index]
        self['hero_icon'].instance.setPixmapFromFile(os.path.join(BASE,'assets',icon+'.png'))
        self['hero_name'].setText('OSCam / السوفتكام' if name=='مشغلات الخدمة' else name)
        self['hero_description'].setText(description)
        self['hero_count'].setText(str(self.section_counts.get(name,0)) + ' عنصر في المكتبة')
        row,col = divmod(self.focus_index,3)
        target = (round((932-col*240)*self.ui_scale[0]),round((153+row*138)*self.ui_scale[1]))
        ring = self['focus_ring'].instance
        if self.motion_target is None:
            ring.move(ePoint(*target))
        else:
            position = ring.position()
            self.motion_start = (position.x(),position.y())
            self.motion_frame = 0
            self.motion_timer.start(18,False)
        self.motion_target = target

    def open_section(self, category=None):
        category=category or HOME_SECTIONS[self.focus_index][0]
        subsets={}
        for item in self.home_catalog:
            if item['category']==category:
                key=subgroup(item)
                subsets[key]=subsets.get(key,0)+1
        if subsets and category != 'الكل':
            self.session.open(StoreSubsections,category,sorted(subsets.items()))
        else:
            self.session.open(SkyBlueStore, initial_category=category)


class StoreSubsections(Screen):
    """Dedicated paged cards, independent of the receiver's ChoiceBox skin."""
    def __init__(self,session,category,groups):
        self.group_entries=groups
        self.group_category=category
        self.group_cursor=0
        xml=['<screen position="0,0" size="1200,660" flags="wfNoBorder" backgroundColor="#0a111b">',
             '<eLabel position="40,28" size="600,48" text="SKY BLUE / COLLECTIONS" font="Regular;32" foregroundColor="#a5e9ed" backgroundColor="#0a111b" />',
             '<widget name="heading" position="650,30" size="510,44" font="Regular;28" halign="right" foregroundColor="#efcf94" backgroundColor="#0a111b" />',
             '<eLabel position="40,100" size="1120,2" backgroundColor="#2b4052" />',
             '<widget name="summary" position="40,112" size="1120,40" font="Regular;21" halign="right" foregroundColor="#acc5d7" backgroundColor="#0a111b" />',
             '<widget name="page" position="40,598" size="350,36" font="Regular;21" foregroundColor="#a5e9ed" backgroundColor="#0a111b" />',
             '<eLabel position="460,598" size="700,36" text="الأسهم: تنقل   |   OK: فتح المجموعة   |   EXIT: رجوع" font="Regular;23" halign="right" foregroundColor="#c9d9e5" backgroundColor="#0a111b" />']
        for i in range(6):
            row,col=divmod(i,3)
            x,y=800-col*380,175+row*200
            xml.extend([
                '<widget name="card%d" position="%d,%d" size="348,180" alphatest="blend" zPosition="0" />'%(i,x,y),
                '<widget name="symbol%d" position="%d,%d" size="300,64" font="Regular;39" halign="center" foregroundColor="#a5e9ed" transparent="1" zPosition="2" />'%(i,x+24,y+18),
                '<widget name="group_icon%d" position="%d,%d" size="64,64" alphatest="blend" zPosition="2" />'%(i,x+142,y+18),
                '<widget name="title%d" position="%d,%d" size="310,43" font="Regular;24" halign="center" foregroundColor="#edf5f8" transparent="1" zPosition="2" />'%(i,x+19,y+92),
                '<widget name="count%d" position="%d,%d" size="310,32" font="Regular;20" halign="center" foregroundColor="#efcf94" transparent="1" zPosition="2" />'%(i,x+19,y+139)])
        desktop=getDesktop(0).size()
        self.skin=fullscreen(''.join(xml)+'</screen>',desktop.width(),desktop.height())
        Screen.__init__(self,session)
        for name in ('heading','summary','page'):self[name]=Label('')
        for i in range(6):
            self['card%d'%i]=Pixmap()
            self['group_icon%d'%i]=Pixmap()
            for name in ('symbol','title','count'):self[name+str(i)]=Label('')
        self['actions']=ActionMap(['OkCancelActions','DirectionActions'],{
            'cancel':self.close,'ok':self.open_group,
            'left':lambda:self.move_group(1),'right':lambda:self.move_group(-1),
            'down':lambda:self.move_group(3),'up':lambda:self.move_group(-3)},-1)
        self.onLayoutFinish.append(self.draw_groups)

    def move_group(self,step):
        self.group_cursor=(self.group_cursor+step)%len(self.group_entries)
        self.draw_groups()

    def draw_groups(self):
        start=(self.group_cursor//6)*6
        self['heading'].setText(self.group_category)
        self['summary'].setText('اختر الصورة أو المجموعة لعرض محتوياتها · التوافق موضح داخل تفاصيل كل إضافة')
        self['page'].setText('صفحة %d / %d'% (start//6+1,(len(self.group_entries)+5)//6))
        symbols={'OpenATV':'ATV','OpenBH':'BH','Egami':'EG','OpenSPA':'SPA','Pure2':'P2','TeamNitro':'NT','OpenViX':'ViX'}
        for i in range(6):
            index=start+i
            components=[self['card%d'%i],self['group_icon%d'%i]]+[self[n+str(i)] for n in ('symbol','title','count')]
            if index>=len(self.group_entries):
                for component in components:component.hide()
                continue
            for component in components:component.show()
            title,count=self.group_entries[index]
            self['card%d'%i].instance.setPixmapFromFile(os.path.join(BASE,'assets','collection-active.png' if index==self.group_cursor else 'collection.png'))
            symbol='PLi' if title.startswith('OpenPLi') else symbols.get(title,'')
            self['symbol%d'%i].setText(symbol)
            if symbol:self['group_icon%d'%i].hide()
            else:self['group_icon%d'%i].instance.setPixmapFromFile(os.path.join(BASE,'assets',group_icon(title,self.group_category)+'.png'))
            self['title%d'%i].setText(title)
            self['count%d'%i].setText(str(count)+' إضافة  ·  '+('محدد' if index==self.group_cursor else 'استعراض'))

    def open_group(self):
        self.session.open(SkyBlueStore,initial_category=self.group_category,subcategory=self.group_entries[self.group_cursor][0])


def main(session, **kwargs):
    from .studio import open_studio
    open_studio(session)


def main_menu(menuid, **kwargs):
    from .preferences import menu_visible
    if menuid=='mainmenu' and menu_visible():
        return [('Sky Blue Store', main, 'skyblue_store', 50)]
    return []


def Plugins(**kwargs):
    return [PluginDescriptor(name='Sky Blue Store', description='Sky Blue Store — Designed by Mohammed Al-Fatlawi',
                             where=PluginDescriptor.WHERE_PLUGINMENU, icon='plugin.png', fnc=main),
            PluginDescriptor(name='Sky Blue Store',where=PluginDescriptor.WHERE_MENU,fnc=main_menu)]
