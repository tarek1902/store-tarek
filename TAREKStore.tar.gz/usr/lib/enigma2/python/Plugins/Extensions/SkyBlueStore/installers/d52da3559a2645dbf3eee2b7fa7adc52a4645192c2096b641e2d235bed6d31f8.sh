#!/bin/sh
# Levi45 Emulator installer - package from https://github.com/levi-45/levi45 (downloads)

NAME="Levi45 Emulator"
BASE="https://raw.githubusercontent.com/levi-45/levi45/refs/heads/main/downloads"
IPK="enigma2-plugin-extensions-levi45emulator_1.4_all.ipk"
DEB=""
PKG="enigma2-plugin-extensions-levi45emulator"

if [ -f /var/lib/dpkg/status ]; then
    FILE="$DEB"
else
    FILE="$IPK"
fi
if [ -z "$FILE" ]; then
    echo "> $NAME has no package for this image (DreamOS)"
    exit 1
fi

echo "> Installing $NAME please wait ..."
rm -f "/tmp/$FILE"
wget -q --no-check-certificate -O "/tmp/$FILE" "$BASE/$FILE" >/dev/null 2>&1
if [ ! -s "/tmp/$FILE" ]; then
    rm -f "/tmp/$FILE"
    echo "> Download failed, $NAME was NOT installed"
    exit 1
fi

if [ -f /var/lib/dpkg/status ]; then
    dpkg -i --force-overwrite "/tmp/$FILE" || apt-get -f -y install
    dpkg -s "$PKG" >/dev/null 2>&1
else
    opkg install --force-reinstall --force-overwrite "/tmp/$FILE" && opkg list-installed "$PKG" | grep "$PKG" >/dev/null
fi
RC=$?
rm -f "/tmp/$FILE"

if [ $RC -ne 0 ]; then
    echo "> $NAME was NOT installed"
    exit 1
fi
sync
echo "> $NAME installed successfully"
echo "> Please restart the GUI"
exit 0
