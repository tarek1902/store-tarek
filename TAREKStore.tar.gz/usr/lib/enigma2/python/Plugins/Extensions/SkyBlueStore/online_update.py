"""Network and package operations run only in worker threads."""
import json
import os
import re
import subprocess
from pathlib import Path
from urllib.request import build_opener,HTTPRedirectHandler
PACKAGE='enigma2-plugin-extensions-skybluestore'
BASE='https://updates.skyblue1.us/e2/'
class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args):raise ValueError('Unexpected redirect')

def validate_manifest(data):
    version=data.get('version','')
    if data.get('package')!=PACKAGE or not re.fullmatch(r'\d{1,4}\.\d{1,4}\.\d{1,4}',version):raise ValueError('بيان الإصدار غير صالح')
    if data.get('url')!=BASE+PACKAGE+'_'+version+'_all.ipk':raise ValueError('رابط التحديث غير صالح')
    if type(data.get('size')) is not int or not 1<=data['size']<=67108864:raise ValueError('حجم التحديث غير صالح')
    if not re.fullmatch('[a-f0-9]{64}',data.get('sha256','')):raise ValueError('بصمة التحديث غير صالحة')
    return version

def inspect_update():
    with build_opener(NoRedirect()).open(BASE+'store-latest.json',timeout=25) as response:raw=response.read(16385)
    if len(raw)>16384:raise ValueError('بيان التحديث أكبر من المسموح')
    data=json.loads(raw);version=validate_manifest(data)
    result=subprocess.run(['opkg','status',PACKAGE],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=15)
    match=re.search(r'^Version:\s*(\S+)',result.stdout.decode('utf-8','replace'),re.M)
    current=match.group(1) if match else '0.0.0'
    newer=subprocess.run(['opkg','compare-versions',version,'>>',current],timeout=10).returncode==0
    return dict(current=current,latest=version,available=newer)

def apply_update():
    lock=Path('/tmp/skyblue-store-install.lock')
    try:fd=os.open(str(lock),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    except FileExistsError:raise ValueError('يوجد تثبيت آخر قيد التشغيل')
    try:
        os.close(fd)
        script=Path(__file__).parent/'update-installer.sh'
        result=subprocess.run(['/bin/sh',str(script)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=300)
        if result.returncode:raise RuntimeError(result.stdout.decode('utf-8','replace')[-1300:])
        return result.stdout.decode('utf-8','replace')[-1300:]
    finally:lock.unlink(missing_ok=True)
