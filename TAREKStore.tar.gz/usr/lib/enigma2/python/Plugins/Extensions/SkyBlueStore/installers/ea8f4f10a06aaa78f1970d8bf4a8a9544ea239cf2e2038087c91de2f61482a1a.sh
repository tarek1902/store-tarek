#!/bin/sh
# GT IPTV Player Pro (Guner Taylan / VicTuS59) - installs the newest stable ipk
# Reads the plugin's own update file, so it always gets the latest version.

PKG="enigma2-plugin-extensions-gtiptvplayerpro"
INFO_URL="https://raw.githubusercontent.com/VicTuS59/GT-IPTV-Player-Pro/main/updates/stable.json"
TMP_INFO="/tmp/gtiptv_stable.json"
TMP_IPK="/tmp/gtiptvplayerpro.ipk"

echo "> GT IPTV Player Pro installer"

if ! command -v opkg >/dev/null 2>&1; then
    echo "> This box has no opkg (DreamOS?). GT IPTV Player Pro is not supported here."
    exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
    echo "> Python 3 is needed (3.9 - 3.14). This image is not supported."
    exit 1
fi

rm -f "$TMP_INFO" "$TMP_IPK"
echo "> Checking the newest version..."
wget -q --no-check-certificate -O "$TMP_INFO" "$INFO_URL?t=$(date +%s)"
if [ ! -s "$TMP_INFO" ]; then
    echo "> Could not download the version information."
    exit 1
fi

URL=$(sed -n 's/.*"url":"\([^"]*\)".*/\1/p' "$TMP_INFO")
VER=$(sed -n 's/.*"version":"\([^"]*\)".*/\1/p' "$TMP_INFO")
SHA=$(sed -n 's/.*"sha256":"\([0-9a-f]*\)".*/\1/p' "$TMP_INFO")
rm -f "$TMP_INFO"

case "$URL" in
    https://github.com/VicTuS59/GT-IPTV-Player-Pro/releases/download/*.ipk) ;;
    *) echo "> Bad version information."; exit 1 ;;
esac

HAVE=$(opkg status "$PKG" 2>/dev/null | sed -n 's/^Version: //p')
if [ "$HAVE" = "$VER" ]; then
    echo "> Version $VER is already installed."
    exit 0
fi

echo "> Downloading version $VER..."
wget -q --no-check-certificate -O "$TMP_IPK" "$URL"
if [ ! -s "$TMP_IPK" ]; then
    echo "> Download failed."
    rm -f "$TMP_IPK"
    exit 1
fi

if [ -n "$SHA" ] && command -v sha256sum >/dev/null 2>&1; then
    GOT=$(sha256sum "$TMP_IPK" | awk '{print $1}')
    if [ "$GOT" != "$SHA" ]; then
        echo "> Checksum is wrong, the download is damaged."
        rm -f "$TMP_IPK"
        exit 1
    fi
    echo "> Checksum OK."
fi

echo "> Updating feeds and installing..."
opkg update >/dev/null 2>&1
opkg install --force-reinstall "$TMP_IPK"
RC=$?
rm -f "$TMP_IPK"

if [ $RC -eq 0 ] && opkg status "$PKG" 2>/dev/null | grep "^Status:.* installed" >/dev/null; then
    echo "> GT IPTV Player Pro $VER installed. Please restart the GUI."
    exit 0
fi
echo "> Install failed."
exit 1
