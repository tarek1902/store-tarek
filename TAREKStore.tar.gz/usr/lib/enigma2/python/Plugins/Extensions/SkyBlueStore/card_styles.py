"""Category identity on shared predictable card geometry."""
import hashlib
PALETTE={'إضافات سكاي بلو':'#edc66e','البلجنات':'#75b4ff','السكنات':'#bd9bff','مشغلات الخدمة':'#edbc66','الوسائط':'#f394c7','القنوات':'#5bddc0','الأيقونات':'#81c9f4','الأدوات':'#f0aa70','النظام':'#88a6ef','النسخ والاستعادة':'#69cfa5','قيد التجهيز':'#b8bdcb'}
def identity(item):return item.get('target_category') or item['category']
def key(category):return hashlib.sha256(category.encode()).hexdigest()[:12]
def surface(item,theme,active):return 'cards/'+key(identity(item))+'-'+str(theme)+('-active' if active else '')+'.png'
