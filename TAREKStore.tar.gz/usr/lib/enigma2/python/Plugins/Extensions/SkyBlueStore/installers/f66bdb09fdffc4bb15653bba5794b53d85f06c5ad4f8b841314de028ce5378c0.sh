#!/bin/sh
# BackupSuite installer (Lululla) - https://github.com/OwnerPlugins/BackupSuite
# Downloads the latest main branch from GitHub and copies it to the box.

NAME="BackupSuite"
URL="https://github.com/OwnerPlugins/BackupSuite/archive/refs/heads/main.tar.gz"
TMPDIR="/tmp/lululla_install"
ROOT="$TMPDIR/BackupSuite-main"
CHECK="usr/lib/enigma2/python/Plugins/Extensions/BackupSuite/plugin.py"

echo "> Installing $NAME please wait ..."
if [ -d /var/lib/opkg ] && [ ! -f /var/lib/dpkg/status ]; then
    echo "> Installing needed packages ..."
    opkg update >/dev/null 2>&1
    for p in bzip2 mtd-utils mtd-utils-ubifs ofgwrite; do
        opkg install "$p" >/dev/null 2>&1
    done
fi
rm -rf "$TMPDIR"
mkdir -p "$TMPDIR" || exit 1

wget -q -O "$TMPDIR/src.tar.gz" "$URL" >/dev/null 2>&1
if [ ! -s "$TMPDIR/src.tar.gz" ]; then
    wget -q --no-check-certificate -O "$TMPDIR/src.tar.gz" "$URL" >/dev/null 2>&1
fi
if [ ! -s "$TMPDIR/src.tar.gz" ]; then
    rm -rf "$TMPDIR"
    echo "> Download failed, $NAME was NOT installed"
    exit 1
fi

if ! tar -xzf "$TMPDIR/src.tar.gz" -C "$TMPDIR" >/dev/null 2>&1; then
    rm -rf "$TMPDIR"
    echo "> Extract failed, $NAME was NOT installed"
    exit 1
fi
if [ ! -f "$ROOT/$CHECK" ]; then
    rm -rf "$TMPDIR"
    echo "> Wrong archive, $NAME was NOT installed"
    exit 1
fi

find "$ROOT/usr" -name "*.pyc" -o -name "*.pyo" | xargs rm -f 2>/dev/null
find "$ROOT/usr" -name "__pycache__" -type d | xargs rm -rf 2>/dev/null
cp -rf "$ROOT/usr" /
rm -rf "$TMPDIR"

if [ ! -f "/$CHECK" ]; then
    echo "> Install check failed, $NAME was NOT installed"
    exit 1
fi
sync
echo "> $NAME installed successfully"
echo "> Please restart the GUI"
exit 0
